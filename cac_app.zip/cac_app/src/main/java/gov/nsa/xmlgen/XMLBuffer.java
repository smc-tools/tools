package gov.nsa.xmlgen;

import gov.nsa.utils.StringUtils;

public class XMLBuffer {
	private StringBuilder b = new StringBuilder();

	public void raw(String s) {
		if (s == null) {
			throw new IllegalArgumentException("parameter may not be null");
		}
		this.b.append(s);
	}

	public void raw(char c) {
		this.b.append(c);
	}

	public void repeatRaw(char c, int i) {
		while (i-- > 0)
			this.b.append(c);
	}

	public void attributeAssignment(String name, String value) {
		if (name == null)
			throw new IllegalArgumentException("parameter may not be null");
		if (value == null) {
			throw new IllegalArgumentException("parameter may not be null");
		}
		this.b.append(' ');
		this.b.append(name);
		this.b.append("=\"");
		this.b.append(StringUtils.replaceSpecialXMLChars(value));
		this.b.append('"');
	}

	public void text(String s) {
		if (s == null)
			throw new IllegalArgumentException("parameter may not be null");
		this.b.append(StringUtils.replaceSpecialXMLChars(s));
	}

	public void openTag_Text_CloseTag(String tag, String text) {
		if (tag == null)
			throw new IllegalArgumentException("parameter may not be null");
		if (text == null) {
			throw new IllegalArgumentException("parameter may not be null");
		}
		openTag(tag);
		text(text);
		closeTag(tag);
	}

	public void openTag(String s) {
		if (s == null)
			throw new IllegalArgumentException("parameter may not be null");
		this.b.append('<');
		this.b.append(s);
		this.b.append('>');
	}

	public void beginOpenTag(String s) {
		if (s == null)
			throw new IllegalArgumentException("parameter may not be null");
		this.b.append('<');
		this.b.append(s);
	}

	public void endOpenTag() {
		this.b.append('>');
	}

	public void endOpenCloseTag() {
		this.b.append("/>");
	}

	public void closeTag(String s) {
		if (s == null)
			throw new IllegalArgumentException("parameter may not be null");
		this.b.append("</");
		this.b.append(s);
		this.b.append('>');
	}

	public int length() {
		return this.b.length();
	}

	public String substring(int start, int end) {
		return this.b.substring(start, end);
	}
}