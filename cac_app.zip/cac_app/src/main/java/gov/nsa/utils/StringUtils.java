package gov.nsa.utils;

public final class StringUtils {

	public static String replaceSpecialXMLChars(String raw) {
		if (raw == null) {
			return null;
		}

		return raw.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(
				">", "&gt;").replaceAll("\"", "&quot;").replaceAll("'",
				"&apos;");
	}

	public static String replaceSpecialJavaStringChars(String raw) {
		if (raw == null) {
			return null;
		}

		StringBuilder buf = new StringBuilder();

		for (int i = 0; i < raw.length(); i++) {
			char c = raw.charAt(i);

			if (c == '"')
				buf.append("\\\"");
			else if (c == '\'')
				buf.append("\\'");
			else if (c == '\\')
				buf.append("\\\\");
			else if (c == '\r')
				buf.append("\\r");
			else if (c == '\n')
				buf.append("\\n");
			else if (c == '\t')
				buf.append("\\t");
			else if (c == '\f')
				buf.append("\\f");
			else if (c == '\b')
				buf.append("\\b");
			else if (c == 0) {
				buf.append("\\000");
			} else {
				buf.append(c);
			}
		}

		return buf.toString();
	}
}