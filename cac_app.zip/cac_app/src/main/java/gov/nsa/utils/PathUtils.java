package gov.nsa.utils;

import java.io.File;

public final class PathUtils {
	public static boolean createDirectory(String path) {
		File f = new File(path);
		if (!f.exists())
			f.mkdir();
		return f.exists();
	}
}