package gov.nsa.utils.collections;

import java.util.ArrayList;
import java.util.List;

public class Queue<T> {
	private List<T> v = new ArrayList<T>();

	public int size() {
		return v.size();
	}

	public T dequeue() {
		T o = this.v.get(0);
		this.v.remove(0);
		return o;
	}

	public void enqueue(T o) {
		this.v.add(o);
	}

	public boolean isEmpty() {
		return v.isEmpty();
	}
}