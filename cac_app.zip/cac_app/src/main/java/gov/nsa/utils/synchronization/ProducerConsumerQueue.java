package gov.nsa.utils.synchronization;

import gov.nsa.utils.collections.Queue;

public class ProducerConsumerQueue<T> {
	private final Queue<T> q = new Queue<T>();
	private final int sizeLimit;

	public ProducerConsumerQueue() {
		this.sizeLimit = -1;
	}

	public synchronized T get() throws InterruptedException {
		while (this.q.isEmpty()) {
			wait();
		}

		T o = this.q.dequeue();

		notifyAll();
		return o;
	}

	public synchronized void put(T value) throws InterruptedException {
		while ((this.sizeLimit > 0) && (this.q.size() >= this.sizeLimit)) {
			wait();
		}

		this.q.enqueue(value);
		notifyAll();
	}
}