package gov.nsa.utils.res;

import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class MessagesHelper {
	private final String bundleName;
	private ResourceBundle resourceBundle;
	private Locale resouceBundleLocale;
	private ResourceBundle resourceBundleOriginal;
	private Map<String, ResourceBundle> resourceBundlesByLocale;

	public MessagesHelper(String bundleName) {
		synchronized (this) {
			this.bundleName = bundleName;
			this.resourceBundleOriginal = ResourceBundle.getBundle(bundleName);
			this.resourceBundle = this.resourceBundleOriginal;
			this.resouceBundleLocale = this.resourceBundle.getLocale();
		}
	}

	public synchronized void reload() {
		this.resourceBundle = ResourceBundle.getBundle(this.bundleName);

		this.resouceBundleLocale = this.resourceBundle.getLocale();
	}

	public synchronized void reload(ResourceBundle newBundle) {
		if (newBundle == null)
			throw new NullPointerException();
		this.resourceBundle = newBundle;
		this.resouceBundleLocale = Locale.getDefault();
	}

	private String getOriginalString(String key) {
		try {
			return this.resourceBundleOriginal.getString(key);
		} catch (MissingResourceException e2) {
		}
		return '!' + key + '!';
	}

	public synchronized String getString(String key) {
		if (Locale.getDefault().getLanguage().equals(
				this.resouceBundleLocale.getLanguage())) {
			try {
				return this.resourceBundle.getString(key);
			} catch (MissingResourceException e1) {
				return getOriginalString(key);
			}

		}

		return getString(Locale.getDefault(), key);
	}

	public synchronized void reload(Locale locale, ResourceBundle newBundle) {
		if (newBundle == null) {
			throw new NullPointerException();
		}
		if (this.resourceBundlesByLocale == null)
			this.resourceBundlesByLocale = new HashMap<String, ResourceBundle>();
		this.resourceBundlesByLocale.put(locale.getLanguage(), newBundle);
	}

	private ResourceBundle getLocaleBundle(Locale locale) {
		if (this.resourceBundlesByLocale == null) {
			this.resourceBundlesByLocale = new HashMap<String, ResourceBundle>();
		}
		ResourceBundle result = this.resourceBundlesByLocale
				.get(locale.getLanguage());
		if (result == null) {
			result = ResourceBundle.getBundle(this.bundleName, locale);
			this.resourceBundlesByLocale.put(locale.getLanguage(), result);
		}
		return result;
	}

	public synchronized String getString(Locale locale, String key) {
		try {
			return getLocaleBundle(locale).getString(key);
		} catch (MissingResourceException e) {
		}
		return getOriginalString(key);
	}

	public synchronized Map<String, String> getStrings(Locale[] locales,
			String key) {
		List<Locale> list = Arrays.asList(locales);
		return getStrings(list, key);
	}

	public synchronized Map<String, String> getStrings(
			Collection<Locale> locales, String key) {
		Map<String, String> result = new HashMap<String, String>();
		for (Locale locale : locales) {
			result.put(locale.toString(), getString(locale, key));
		}
		return result;
	}

	public synchronized Enumeration<String> getKeys() {
		return this.resourceBundle.getKeys();
	}
}