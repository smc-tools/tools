package gov.nsa.utils.synchronization;

public abstract class CloseableThread extends Thread {
	protected final SynchronizedBoolean closing = new SynchronizedBoolean(false);
	private final SynchronizedBoolean closed = new SynchronizedBoolean(false);

	public CloseableThread(ThreadGroup group, String threadName) {
		super(group, threadName);
	}

	public void close() {
		this.closing.setValue(true);
		interrupt();
	}

	protected void setClosing() {
		this.closing.setValue(true);
	}

	public boolean isClosed() {
		return this.closed.getValue();
	}

	public void waitUntilClosed() throws InterruptedException {
		this.closed.waitUntil(true);
	}

	protected boolean isClosing() {
		return this.closing.getValue();
	}

	protected void setClosed() {
		this.closed.setValue(true);
	}
}