package gov.nsa.utils.synchronization;

public class MessageDrivenThread extends CloseableThread {
	private MessageDrivenThreadListener listener;
	private ProducerConsumerQueue<Object> q = new ProducerConsumerQueue<Object>();

	public MessageDrivenThread(ThreadGroup group, String threadName,
			MessageDrivenThreadListener listener) {
		super(group, threadName);
		this.listener = listener;
	}

	public MessageDrivenThread(ThreadGroup group, String threadName) {
		super(group, threadName);
	}

	public void setListener(MessageDrivenThreadListener listener) {
		this.listener = listener;
	}

	@Override
	public void run() {
		try {
			while (!isClosing()) {
				Object o = q.get();

				doMessageReceived(o);
			}
		} catch (InterruptedException e) {
		} finally {
			setClosed();
		}
	}

	protected void doMessageReceived(Object o) {
		if (listener != null)
			listener.onMessage(this, o);
	}
}