package gov.nsa.utils.synchronization;

public interface MessageDrivenThreadListener {
	void onMessage(MessageDrivenThread paramMessageDrivenThread,
			Object paramObject);
}