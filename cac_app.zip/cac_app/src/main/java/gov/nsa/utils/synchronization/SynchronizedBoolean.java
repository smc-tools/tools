package gov.nsa.utils.synchronization;

public class SynchronizedBoolean {
	private boolean b = false;

	// public SynchronizedBoolean()
	// {
	// }
	//
	public SynchronizedBoolean(boolean initValue) {
		this.b = initValue;
	}

	public synchronized boolean getValue() {
		return this.b;
	}

	public synchronized void setValue(boolean newValue) {
		if (this.b != newValue) {
			this.b = newValue;
			notifyAll();
		}
	}

	public synchronized void waitUntil(boolean value)
			throws InterruptedException {
		while (this.b != value) {
			wait();
		}
	}
}