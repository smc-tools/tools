package gov.nsa.cac;

import java.io.IOException;

public class CACRecordFileParser {
	public static void parseFile(String path,
			CACRecordFileParserObserver observer) throws IOException {
		String[] strings = LineBasedFileSplitter.splitFile(path);
		parseStrings(strings, observer);
	}

	public static void parseStrings(String[] strings,
			CACRecordFileParserObserver observer) {
		for (int i = 0; i < strings.length; i++) {
			String raw = strings[i].trim();
			if (!raw.equals("")) {
				try {
					CACRecord record = new CACRecord(raw);
					observer.onCACRecord(record);
				} catch (FormatException e) {
					observer.onCACRecordFormatException(raw, e);
				}
			}
		}

		observer.onEOS();
	}
}