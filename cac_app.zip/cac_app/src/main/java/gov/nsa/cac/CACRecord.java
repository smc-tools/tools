package gov.nsa.cac;

public class CACRecord extends Record {
	public static final String EMPLID = "$emplid";
	public static final String S = "'S'";
	public static final String LN = "$ln";
	public static final String FN = "$fn";
	public static final String MN = "$mn";
	public static final String SUFFIX = "$suffix";
	public static final String BD = "$bd";
	public static final String SEX = "$sex";
	public static final String CITZ = "$citz";
	public static final String COUNTRY = "$country";
	public static final String C = "'C'";
	public static final String STARTDT = "$startdt";
	public static final String EXPDT = "$expdt";
	public static final String EXPCD = "$expcd";
	public static final String ENDDT = "$enddt";
	public static final String TERMRSN = "$termrsn";
	public static final String AGCYCD = "$agcycd";
	public static final String TRANSCD = "$transcd";
	public static final String TRANDT = "$trandt";
	public static final String PAYPLAN = "$payplan";
	public static final String GRADE = "$grade";
	public static final String PAYDT = "$paydt";
	public static final String ASGORG = "$asgorg";
	public static final FieldDescriptor[] fieldDescriptors = {
			FieldDescriptor.parse("$emplid:9        !1-9      SSN", 0),
			FieldDescriptor.parse("'S':1            !10       ID TYPE (S=SSN)",
					0),
			FieldDescriptor.parse("$ln:26           !11-36    LAST NAME", 1),
			FieldDescriptor.parse("$fn:20           !37-56    FIRST NAME", 1),
			FieldDescriptor.parse("$mn:20           !57-76    MIDDLE NAME", 1),
			FieldDescriptor.parse("$suffix:4        !77-80    SUFFIX", 1),
			FieldDescriptor.parse(
					"$bd:8            !81-88    BIRTHDATE (YYYYMMDD)", 2),
			FieldDescriptor
					.parse("$sex:1           !89       SEX (M, F, Z)", 0),
			FieldDescriptor.parse(
					"$citz:1          !90       CITIZENSHIP (Y, N, Z)", 0),
			FieldDescriptor.parse(
					"$country:2       !91-92    LOCATION COUNTRY", 1),
			FieldDescriptor.parse(
					"'C':1            !93       CATEGORY (C=Civilian)", 0),
			FieldDescriptor.parse(
					"$startdt:8       !94-101   DATE OF HIRE (YYYYMMDD)", 2),
			FieldDescriptor.parse(
					"$expdt:8         !102-109  EXPIRATION DATE (YYYYMMDD)", 2),
			FieldDescriptor.parse(
					"$expcd:1         !110      EXPIRATION CODE (R,U)", 0),
			FieldDescriptor.parse(
					"$enddt:8         !111-118  END DATE (YYYYMMDD)", 2),
			FieldDescriptor
					.parse(
							"$termrsn:1       !119      TERMINATION REASON (S=Separated, D=Deceased, W=Active)",
							0),
			FieldDescriptor.parse(
					"$agcycd:4        !120-123  AGENCY CODE (DD00)", 1),
			FieldDescriptor
					.parse(
							"$transcd:1       !124      TRANSACTION CODE (C=Change, G=Gain, L=Loss)",
							0),
			FieldDescriptor
					.parse(
							"$trandt:8        !125-132  TRANSACTION DATE (YYYYMMDD)",
							2),
			FieldDescriptor.parse("$payplan:5       !133-137  PAY PLAN", 1),
			FieldDescriptor.parse("$grade:2         !138-139  PAY GRADE", 1),
			FieldDescriptor.parse(
					"$paydt:8         !140-147  PAY GRADE DATE (YYYYMMDD)", 2),
			FieldDescriptor.parse("$asgorg:8        !148-155  ASSIGNED ORG", 1) };

	private static final RecordDescriptor recordDescriptor = new RecordDescriptor(
			fieldDescriptors);

	public CACRecord() {
		super(recordDescriptor);
	}

	public CACRecord(String value) throws FormatException {
		super(recordDescriptor, value);
	}
}