package gov.nsa.cac;

public interface CACRecordFileParserObserver {
	void onCACRecord(CACRecord paramCACRecord);

	void onCACRecordFormatException(String paramString,
			FormatException paramFormatException);

	void onEOS();
}