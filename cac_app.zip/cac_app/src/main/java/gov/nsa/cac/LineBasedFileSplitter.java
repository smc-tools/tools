package gov.nsa.cac;

import java.io.FileInputStream;
import java.io.IOException;

public class LineBasedFileSplitter {
	public static String[] splitFile(String path) throws IOException {
		FileInputStream is = new FileInputStream(path);

		StringBuffer b = new StringBuffer();
		int c;
		while ((c = is.read()) != -1) {
			b.append((char) c);
		}
		is.close();
		return splitString(b.toString());
	}

	public static String[] splitString(String text) {
		boolean rnFound = text.indexOf("\r\n") >= 0;

		String[] lines1 = text.split("\r\n");
		String[] lines2 = text.split("\n");

		if (!rnFound) {
			return lines2;
		}
		String[] lines = lines1.length >= lines2.length ? lines1 : lines2;

		return lines;
	}
}