package gov.nsa.cac;

public class FieldDescriptor {
	private String columnName;
	private int offset;
	private int length;
	private String description;
	private int type;
	public static final int RAW_STRING = 0;
	public static final int TRAILING_SPACE_PADDED_STRING = 1;
	public static final int DATE = 2;

	public FieldDescriptor() {
	}

	public static FieldDescriptor parse(String s, int type) {
		s = s.trim();

		int colonIndex = s.indexOf(':');
		if (colonIndex < 0) {
			System.err.println(s);
			throw new IllegalArgumentException("Expected ':'");
		}
		int bangIndex = s.indexOf('!', colonIndex);
		if (bangIndex < 0) {
			System.err.println(s);
			throw new IllegalArgumentException("Expected '!'");
		}

		int dashIndex = s.indexOf('-', bangIndex);

		int spaceIndex = s.indexOf(' ', dashIndex >= 0 ? dashIndex : bangIndex);
		if (spaceIndex < 0) {
			System.err.println(s);
			throw new IllegalArgumentException("Expected ' '");
		}

		String s0 = s.substring(0, colonIndex).trim();
		String s1 = s.substring(colonIndex + 1, bangIndex).trim();
		String s2 = s.substring(bangIndex + 1,
				dashIndex >= 0 ? dashIndex : spaceIndex).trim();
		String s3;
		if (dashIndex >= 0)
			s3 = s.substring(dashIndex + 1, spaceIndex).trim();
		else {
			s3 = s2;
		}
		String s4 = s.substring(spaceIndex + 1, s.length()).trim();

		FieldDescriptor fd = new FieldDescriptor();
		fd.setColumnName(s0);
		fd.setLength(Integer.parseInt(s1));
		fd.setOffset(Integer.parseInt(s2) - 1);
		int endIndex = Integer.parseInt(s3) - 1;
		if (fd.getOffset() + fd.getLength() - 1 != endIndex) {
			System.err.println(s);
			System.err.println("Offset: " + fd.getOffset());
			System.err.println("Length: " + fd.getLength());
			System.err.println("endIndex: " + endIndex);
			throw new IllegalArgumentException(
					"Length and end index do not match.");
		}
		fd.setDescription(s4);

		fd.setType(type);
		return fd;
	}

	public FieldDescriptor(String name, int offset, int length,
			String description) {
		this.columnName = name;
		this.offset = offset;
		this.length = length;
		this.description = description;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getLength() {
		return this.length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public String getColumnName() {
		return this.columnName;
	}

	public void setColumnName(String name) {
		this.columnName = name;
	}

	public int getOffset() {
		return this.offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getType() {
		return this.type;
	}

	public void setType(int type) {
		this.type = type;
	}
}