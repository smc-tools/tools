package gov.nsa.cac;

import java.util.HashMap;
import java.util.Map;

public class RecordDescriptor {
	private FieldDescriptor[] fieldDescriptors;
	private Map<String, FieldDescriptor> indexByColumnName = new HashMap<String, FieldDescriptor>();

	public RecordDescriptor(FieldDescriptor[] fieldDescriptors) {
		this.fieldDescriptors = fieldDescriptors;
		buildIndex();
	}

	public int getOffset(String columnName) {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return getOffset(fd);
	}

	public int getLength(String columnName) {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return fd.getLength();
	}

	public int getType(String columnName) {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return fd.getType();
	}

	public int getOffset(FieldDescriptor fd) {
		for (int i = 0; i < this.fieldDescriptors.length; i++) {
			if (this.fieldDescriptors[i] == fd)
				return fd.getOffset();
		}
		throw new IllegalArgumentException("Unknown column");
	}

	public int getTotalLength() {
		int length = 0;
		for (int i = 0; i < this.fieldDescriptors.length; i++) {
			length += this.fieldDescriptors[i].getLength();
		}
		return length;
	}

	private FieldDescriptor getFieldDescriptorByColumnName(String columnName) {
		return this.indexByColumnName.get(columnName);
	}

	private void buildIndex() {
		this.indexByColumnName.clear();
		for (FieldDescriptor fd : fieldDescriptors) {
			if (getFieldDescriptorByColumnName(fd.getColumnName()) != null)
				throw new RuntimeException("Duplicate column name: "
						+ fd.getColumnName());
			this.indexByColumnName.put(fd.getColumnName(), fd);
		}
	}
}