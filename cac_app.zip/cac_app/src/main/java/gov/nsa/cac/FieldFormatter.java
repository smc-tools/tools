package gov.nsa.cac;

import org.apache.commons.lang3.StringUtils;

public class FieldFormatter {
	public static String formatTrailingSpacePaddedString(String value, int len)
			throws FormatException {
		String s = value;
		if (s.length() > len)
			throw new FormatException(
					"String is too large to fit in field of length " + len
							+ ": [" + value + "]");
		return StringUtils.rightPad(s, len, " ");
	}

	public static String parseTrailingSpacePaddedString(String value)
			throws FormatException {
		return (value == null) ? null : value.trim();
	}

	public static String formatDate(Date value) throws FormatException {
		return formatZeroPaddedString(value.getYear(), 4)
				+ formatZeroPaddedString(value.getMonth(), 2)
				+ formatZeroPaddedString(value.getDay(), 2);
	}

	public static Date parseDate(String value) throws FormatException {
		if (value.trim().equals("")) {
			return new Date();
		}
		if (value.length() != 8) {
			throw new FormatException("Expected date field to have length 8");
		}
		String yearStr = value.substring(0, 4);
		String monthStr = value.substring(4, 6);
		String dayStr = value.substring(6, 8);
		try {
			int year = parseZeroPaddedString(yearStr);
			int month = parseZeroPaddedString(monthStr);
			int day = parseZeroPaddedString(dayStr);
			return new Date(year, month, day);
		} catch (FormatException e) {
			throw new FormatException("Expected number in date field", e);
		}
	}

	private static String formatZeroPaddedString(int value, int len)
			throws FormatException {
		String s = Integer.toString(value);

		if (s.length() > len)
			throw new FormatException(
					"Number is too large to fit in field of length " + len
							+ ": " + value);
		return StringUtils.leftPad(s, len, "0");
	}

	private static int parseZeroPaddedString(String s) throws FormatException {
		try {
			return Integer.parseInt(s);
		} catch (NumberFormatException e) {
			throw new FormatException("Expected number", e);
		}
	}
}