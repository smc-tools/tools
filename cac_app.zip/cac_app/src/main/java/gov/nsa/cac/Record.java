package gov.nsa.cac;

public class Record {
	private RecordDescriptor recordDescriptor;
	private char[] buf;

	public Record(RecordDescriptor recordDescriptor) {
		this.recordDescriptor = recordDescriptor;
		this.buf = new char[recordDescriptor.getTotalLength()];
		clearBuf();
	}

	public Record(RecordDescriptor recordDescriptor, String value)
			throws FormatException {
		this.recordDescriptor = recordDescriptor;
		setFrom(value);
	}

	public void setFrom(String value) throws FormatException {
		this.buf = new char[this.recordDescriptor.getTotalLength()];
		clearBuf();

		char[] src = value.toCharArray();
		int len = this.buf.length;
		if (src.length < len)
			len = src.length;
		System.arraycopy(src, 0, this.buf, 0, len);
	}

	@Override
	public String toString() {
		return new String(this.buf);
	}

	private void clearBuf() {
		for (int i = 0; i < this.buf.length; i++)
			this.buf[i] = ' ';
	}

	public RecordDescriptor getRecordDescriptor() {
		return this.recordDescriptor;
	}

	public void setRawField(String columnName, String value)
			throws FormatException {
		int offset = this.recordDescriptor.getOffset(columnName);
		int len = this.recordDescriptor.getLength(columnName);
		if (value.length() != len)
			throw new FormatException("Expected length of " + len
					+ " for column " + columnName);
		char[] src = value.toCharArray();
		System.arraycopy(src, 0, this.buf, offset, len);
	}

	public String getRawField(String columnName) throws FormatException {
		int offset = this.recordDescriptor.getOffset(columnName);
		int len = this.recordDescriptor.getLength(columnName);
		return new String(this.buf, offset, len);
	}

	public int getColonTerminatedNumberField(String columnName)
			throws FormatException {
		String s = getRawField(columnName);
		if (!s.endsWith(":"))
			throw new RuntimeException("Expected :");
		s = s.substring(0, s.length() - 1);
		try {
			return Integer.parseInt(s);
		} catch (NumberFormatException e) {
			throw new FormatException("Expected number", e);
		}
	}

	public FormatException buildGetFieldFormatException(String columnName,
			String message, FormatException e) {
		return new FormatException("Failed to get field " + columnName + ": "
				+ message, e);
	}

	public Date getDateField(String columnName) throws FormatException {
		String value = getRawField(columnName);
		try {
			return FieldFormatter.parseDate(value);
		} catch (FormatException e) {
			throw buildGetFieldFormatException(columnName,
					": Failed to parse date [" + value + "]", e);
		}
	}

	public void setDateField(String columnName, Date value)
			throws FormatException {
		setRawField(columnName, FieldFormatter.formatDate(value));
	}

	public void setTrailingSpacePaddedStringField(String columnName,
			String value) throws FormatException {
		int len = this.recordDescriptor.getLength(columnName);
		setRawField(columnName, FieldFormatter.formatTrailingSpacePaddedString(
				value, len));
	}

	public String getTrailingSpacePaddedStringField(String columnName)
			throws FormatException {
		return FieldFormatter
				.parseTrailingSpacePaddedString(getRawField(columnName));
	}

	public int getType(String columnName) {
		return this.recordDescriptor.getType(columnName);
	}

	public Object getValue(String columnName) throws FormatException {
		int type = this.recordDescriptor.getType(columnName);
		switch (type) {
		case 0:
			return getRawField(columnName);
		case 1:
			return getTrailingSpacePaddedStringField(columnName);
		case 2:
			return getDateField(columnName);
		}
		throw new RuntimeException("Unknown type: " + type);
	}
}