package gov.nsa.cac;

public class FormatException extends Exception {
	public FormatException() {
	}

	public FormatException(String arg0) {
		super(arg0);
	}

	public FormatException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public FormatException(Throwable arg0) {
		super(arg0);
	}
}