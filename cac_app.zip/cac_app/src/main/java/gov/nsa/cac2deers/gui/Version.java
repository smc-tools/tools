package gov.nsa.cac2deers.gui;

public class Version
{
  public static String getVersion()
  {
    return "0.3";
  }
}