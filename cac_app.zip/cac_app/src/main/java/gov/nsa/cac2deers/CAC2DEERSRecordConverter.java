package gov.nsa.cac2deers;

import gov.nsa.cac.CACRecord;
import gov.nsa.deers.DEERSTransferRecord;


public class CAC2DEERSRecordConverter {
	public static DEERSTransferRecord convert(CACRecord in)
			throws gov.nsa.deers.FormatException,
			gov.nsa.cac.FormatException {
		DEERSTransferRecord out = new DEERSTransferRecord();

		out.setRawField("SPN_PN_ID", in.getRawField("$emplid"));
		out.setRawField("SPN_PN_ID_TYP_CD", in.getRawField("'S'"));
		out.setTrailingSpacePaddedStringField("PN_LST_NM", in
				.getTrailingSpacePaddedStringField("$ln"));
		out.setTrailingSpacePaddedStringField("PN_1ST_NM", in
				.getTrailingSpacePaddedStringField("$fn"));
		out.setTrailingSpacePaddedStringField("PN_MID_NM", in
				.getTrailingSpacePaddedStringField("$mn"));
		out.setTrailingSpacePaddedStringField("PN_CDNCY_NM", in
				.getTrailingSpacePaddedStringField("$suffix"));
		out.setDateField("PN_BRTH_DT", convertDate(in.getDateField("$bd")));
		out.setRawField("PN_SEX_CD", in.getRawField("$sex"));
		out.setRawField("US_CTZP_STAT_CD", in.getRawField("$citz"));
		out.setRawField("LOC_CTRY_CD", in.getRawField("$country"));
		out.setRawField("PNL_CAT_CD", in.getRawField("'C'"));
		out
				.setDateField("PNL_BGN_DT", convertDate(in
						.getDateField("$startdt")));
		out.setDateField("PNL_PE_DT", convertDate(in.getDateField("$expdt")));
		out.setRawField("PNL_PEDC_CD", in.getRawField("$expcd"));
		out.setDateField("PNL_TERM_DT", convertDate(in.getDateField("$enddt")));
		out.setRawField("PNL_TRSN_CD", in.getRawField("$termrsn"));
		out.setRawField("USGVT_AGCY_CD", in.getRawField("$agcycd"));
		out.setRawField("PNL_TXN_TYP_CD", in.getRawField("$transcd"));
		out.setDateField("PNL_TXN_DT", convertDate(in.getDateField("$trandt")));
		out.setRawField("PAY_PLN_CD", in.getRawField("$payplan"));
		out.setRawField("PG_CD", in.getRawField("$grade"));
		out.setDateField("PG_DT", convertDate(in.getDateField("$paydt")));
		out.setRawField("UNIT_ID_CD", in.getRawField("$asgorg"));

		return out;
	}

	private static gov.nsa.deers.Date convertDate(gov.nsa.cac.Date d) {
		if (d == null)
			return null;
		return new gov.nsa.deers.Date(d.getYear(), d.getMonth(), d
				.getDay());
	}
}