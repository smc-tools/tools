package gov.nsa.cac2deers.gui;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class HTMLLogTransformer {

	public static String outputHTMLPath(String inputXMLPath) {
		String outputHTMLPath = inputXMLPath;

		if (outputHTMLPath.endsWith(".xml"))
			outputHTMLPath = outputHTMLPath.substring(0, outputHTMLPath
					.length()
					- ".xml".length());
		outputHTMLPath = outputHTMLPath + ".html";
		return outputHTMLPath;
	}

	public static void transform(String inputXMLPath) throws IOException,
			TransformerException {
		InputStream xslStream = ClassLoader.getSystemClassLoader().getResourceAsStream("xmllog.xsl");
		Transformer transformer = TransformerFactory.newInstance()
				.newTransformer(new StreamSource(xslStream));

		InputStream inputStream = new FileInputStream(inputXMLPath);
		String outputHTMLPath = outputHTMLPath(inputXMLPath);
		OutputStream outputStream = new FileOutputStream(outputHTMLPath);
		transformer.transform(new StreamSource(inputStream), new StreamResult(
				outputStream));

		xslStream.close();
		outputStream.close();
		inputStream.close();
	}
}