package gov.nsa.cac2deers;

import gov.nsa.cac.CACRecordFileParser;

import java.io.IOException;

public class CAC2DEERSRecordFileConverter {
	public static void parseFile(String path,
			CAC2DEERSRecordFileConverterObserver observer) throws IOException {
		CACRecordFileParser.parseFile(path, new CAC2DEERSConvertingObserver(
				observer));
	}
}