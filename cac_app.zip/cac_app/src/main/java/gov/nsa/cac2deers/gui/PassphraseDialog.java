package gov.nsa.cac2deers.gui;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class PassphraseDialog extends Dialog
{
  protected Text textPassphrase;
  protected PassphraseDialogResult result;

  public PassphraseDialog(Shell arg0)
  {
    super(arg0);
  }

  @Override
protected Control createDialogArea(Composite parent)
  {
    Composite container = (Composite)super.createDialogArea(parent);
    GridLayout gridLayout = new GridLayout();
    gridLayout.numColumns = 2;
    gridLayout.marginWidth = 25;
    container.setLayout(gridLayout);

    Label labelPassphrase = new Label(container, 0);
    GridData gridData = new GridData(128);
    gridData.horizontalSpan = 1;
    labelPassphrase.setLayoutData(gridData);
    labelPassphrase.setText(Messages.getString("PassphraseDialog.Passphrase"));

    this.textPassphrase = new Text(container, 4196352);
    gridData = new GridData(768);
    gridData.horizontalSpan = 1;
    this.textPassphrase.setLayoutData(gridData);

    return container;
  }

  @Override
protected void okPressed()
  {
    this.result = new PassphraseDialogResult(this.textPassphrase.getText());
    super.okPressed();
  }

  @Override
protected void createButtonsForButtonBar(Composite parent) {
    createButton(parent, 0, Messages.getString("PassphraseDialog.OK"), true);
    createButton(parent, 1, Messages.getString("PassphraseDialog.Cancel"), false);
  }

  @Override
protected Point getInitialSize()
  {
    return new Point(300, 200);
  }

  @Override
protected void configureShell(Shell newShell)
  {
    super.configureShell(newShell);
    newShell.setText(Messages.getString("PassphraseDialog.Title"));
  }

  public static PassphraseDialogResult run(Shell shell)
  {
    PassphraseDialog f = new PassphraseDialog(shell);
    f.open();

    if (f.getReturnCode() == 0) {
      return f.result;
    }
    return null;
  }
}