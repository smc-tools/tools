package gov.nsa.cac2deers.gui;

import gov.nsa.cac2deers.CAC2DEERSTransferEngineObserver;
import gov.nsa.cac2deers.CAC2DEERSTransferEngineThread;
import gov.nsa.cac2deers.CAC2DEERSTransferEngineThreadObserver;
import gov.nsa.cac2deers.LogItem;
import gov.nsa.utils.PathUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.eclipse.swt.custom.StackLayout;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Cursor;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.program.Program;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.MessageBox;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

public class CAC2DEERSWizard {
	private static final Logger logger = Logger.getLogger(CAC2DEERSWizard.class
			.getName());
	private final Shell shell;
	private Composite titleArea;
	private Label title;
	private Composite mainArea;
	private Composite miniArea1;
	private Composite miniArea2;
	private StackLayout mainAreaLayout;
	private Text filePath;
	private Label spacer;
	private Label totalNum;
	private Label successNumText;
	private Label failedNumText;
	private Composite buttonArea;
	private Button start;
	private Button viewLogButton;
	private Button viewFailuresButton;
	private ProgressBar bar;
	private Button cancelOrCloseButton;
	private Text logText;
	private static final String[] FILTER_NAMES = { "Data File (*.dat)" };
	private static final String[] FILTER_EXTS = { "*.dat" };
	private String keystorePath;
	private String hostURL;
	//private String host;
	//private int port;
	// private static final String OUTPUT_PATH = "log";
	// private static final String XML_ALL_LOG_FILENAME_SUFFIX = "all.log.xml";
	// private static final String XML_FAILURE_LOG_FILENAME_SUFFIX =
	// "failures.log.xml";
	private XMLLogger xmlAllLogger;
	private XMLLogger xmlFailureLogger;
	private int failedNum = 0;
	private int successNum = 0;

	static final String newLine = System.getProperty("line.separator");
	private CAC2DEERSTransferEngineThread transferEngineThread;

	public CAC2DEERSWizard(Shell shell) {
		this.shell = shell;
	}

	public void run() throws FileNotFoundException, IOException {
		Properties properties = new Properties();
		InputStream is = ClassLoader.getSystemClassLoader()
				.getResourceAsStream("cac2deers.properties");

		properties.load(is);
		this.keystorePath = properties.getProperty("deers.keystore");
		this.hostURL = properties.getProperty("deers.hostURL");
		//this.host = properties.getProperty("deers.host");
		//this.port = Integer.parseInt(properties.getProperty("deers.port"));

		configureShell();
		createTitleArea();
		createMainArea();
		createButtonArea();
	}

	private void configureShell() {
		this.shell.setText(Messages.getString("DeersWizard.ShellTitle")
				.replaceAll("%1", Version.getVersion()));
		GridLayout mainLayout = new GridLayout(1, true);
		mainLayout.marginWidth = 8;
		mainLayout.marginHeight = 8;
		this.shell.setLayout(mainLayout);
	}

	private void createTitleArea() {
		this.titleArea = new Composite(this.shell, 0);

		GridData titleAreaData = new GridData(1808);
		titleAreaData.heightHint = 50;
		titleAreaData.widthHint = 450;
		this.titleArea.setLayoutData(titleAreaData);
		GridLayout titleAreaLayout = new GridLayout(1, true);
		this.titleArea.setLayout(titleAreaLayout);

		this.title = new Label(this.titleArea, 2048);
		GridData titleData = new GridData(1808);

		this.title.setText(Messages.getString("DeersWizard.Page1TitleText"));
		this.title.setLayoutData(titleData);
	}

	private void createMainArea() {
		this.mainArea = new Composite(this.shell, 0);
		GridData mainAreaData = new GridData(1808);
		mainAreaData.heightHint = 442;
		mainAreaData.widthHint = 600;
		this.mainArea.setLayoutData(mainAreaData);
		this.mainAreaLayout = new StackLayout();
		this.mainArea.setLayout(this.mainAreaLayout);

		this.miniArea1 = new Composite(this.mainArea, 0);
		GridLayout miniArea1Layout = new GridLayout(3, false);

		this.miniArea1.setLayout(miniArea1Layout);

		this.filePath = new Text(this.miniArea1, 18444);
		GridData filePathData = new GridData(768);
		filePathData.horizontalSpan = 2;
		filePathData.heightHint = 14;
		this.filePath.setLayoutData(filePathData);

		Button browse = new Button(this.miniArea1, 8);
		GridData browseButtonData = new GridData();
		browse.setLayoutData(browseButtonData);
		browse.setText(Messages.getString("DeersWizard.ButtonBrowse"));
		browse.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				FileDialog dlg = new FileDialog(CAC2DEERSWizard.this.shell,
						4096);
				dlg.setFilterNames(CAC2DEERSWizard.FILTER_NAMES);
				dlg.setFilterExtensions(CAC2DEERSWizard.FILTER_EXTS);
				String fn = dlg.open();
				if (fn != null) {
					CAC2DEERSWizard.this.filePath.setText(fn);
					CAC2DEERSWizard.this.start.setEnabled(true);
				}
			}
		});
		this.miniArea2 = new Composite(this.mainArea, 0);
		GridLayout miniArea2Layout = new GridLayout(2, true);
		miniArea2Layout.marginHeight = 5;
		miniArea2Layout.marginWidth = 8;
		miniArea2Layout.horizontalSpacing = 15;
		this.miniArea2.setLayout(miniArea2Layout);

		this.bar = new ProgressBar(this.miniArea2, 65792);
		GridData barData = new GridData(768);
		barData.horizontalSpan = 2;
		this.bar.setLayoutData(barData);

		Label total = new Label(this.miniArea2, 0);
		total.setText(Messages.getString("DeersWizard.LabelTotal"));
		GridData totalData = new GridData();
		total.setLayoutData(totalData);

		this.totalNum = new Label(this.miniArea2, 133120);
		this.totalNum.setText("");
		GridData totalNumData = new GridData(768);
		this.totalNum.setLayoutData(totalNumData);

		Label successful = new Label(this.miniArea2, 0);
		successful.setText(Messages.getString("DeersWizard.LabelSucceeded"));
		GridData successfulData = new GridData();
		successful.setLayoutData(successfulData);

		this.successNumText = new Label(this.miniArea2, 133120);
		this.successNumText.setText("");
		GridData successNumData = new GridData(768);
		this.successNumText.setLayoutData(successNumData);

		Label failed = new Label(this.miniArea2, 0);
		failed.setText(Messages.getString("DeersWizard.LabelFailed"));
		GridData failedData = new GridData();
		failed.setLayoutData(failedData);

		this.failedNumText = new Label(this.miniArea2, 133120);
		this.failedNumText.setText("");
		GridData failedNumData = new GridData(768);
		this.failedNumText.setLayoutData(failedNumData);

		this.logText = new Text(this.miniArea2, 2570);
		GridData successLogData = new GridData(1808);
		successLogData.horizontalSpan = 2;
		this.logText.setLayoutData(successLogData);

		this.mainAreaLayout.topControl = this.miniArea1;

		this.spacer = new Label(this.shell, 258);
		GridData spacerData = new GridData(768);
		this.spacer.setLayoutData(spacerData);
	}

	private void createButtonArea() {
		this.buttonArea = new Composite(this.shell, 131072);
		GridData buttonAreaData = new GridData(128);
		buttonAreaData.heightHint = 40;
		this.buttonArea.setLayoutData(buttonAreaData);
		GridLayout buttonAreaLayout = new GridLayout(4, true);
		this.buttonArea.setLayout(buttonAreaLayout);

		this.start = new Button(this.buttonArea, 12);
		this.start.setText(Messages.getString("DeersWizard.ButtonStart"));
		GridData startData = new GridData(256);
		this.start.setLayoutData(startData);
		this.start.setEnabled(false);
		this.start.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				CAC2DEERSWizard.this.onStartTransfer();
			}
		});
		this.viewLogButton = new Button(this.buttonArea, 12);
		this.viewLogButton.setText(Messages.getString("DeersWizard.ButtonLog"));
		GridData logData = new GridData(256);
		this.viewLogButton.setLayoutData(logData);
		this.viewLogButton.setEnabled(false);
		this.viewLogButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				CAC2DEERSWizard.this.onViewLog();
			}
		});
		this.viewFailuresButton = new Button(this.buttonArea, 12);
		this.viewFailuresButton.setText(Messages
				.getString("DeersWizard.ButtonFailures"));
		GridData failuresData = new GridData(256);
		this.viewFailuresButton.setLayoutData(failuresData);
		this.viewFailuresButton.setEnabled(false);
		this.viewFailuresButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				CAC2DEERSWizard.this.onViewFailures();
			}
		});
		this.cancelOrCloseButton = new Button(this.buttonArea, 12);
		this.cancelOrCloseButton.setText(Messages
				.getString("DeersWizard.ButtonClose"));
		GridData cancelData = new GridData(256);
		this.cancelOrCloseButton.setLayoutData(cancelData);
		this.cancelOrCloseButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent event) {
				CAC2DEERSWizard.this.onCancelOrClose();
			}
		});
	}

	private void setTitleText(String text) {
		this.title.setText(text);
	}

	private void showError(Exception e) {
		logger.error(e, e);
		showError(e.getMessage());
	}

	private void showError(String message) {
		MessageBox m = new MessageBox(this.shell, 33);
		m.setMessage("" + message);

		m.open();
	}

	private int getFailedNum() {
		return this.failedNum;
	}

	private void incrementFailedNum() {
		this.failedNum += 1;
		this.failedNumText.setText("" + this.failedNum);
	}

	private void incrementSuccessNum() {
		this.successNum += 1;
		this.successNumText.setText("" + this.successNum);
	}

	private void appendLogText(String s) {
		String prevText = this.logText.getText();
		this.logText.setText(prevText + s + newLine);
		logger.debug(s);
	}

	private static String zeroPad(int value, int len) {
		String result = "" + value;
		while (result.length() < len)
			result = "0" + result;
		return result;
	}

	private static String newTranferId(Date date) {
		// String SEP1 = "";
		// String SEP2 = "-";
		// String SEP3 = "";
		// String SEP4 = ".";
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		String result = "";

		result = result + zeroPad(calendar.get(1), 4);
		result = result + "";
		result = result + zeroPad(calendar.get(2) + 1, 2);
		result = result + "";
		result = result + zeroPad(calendar.get(5), 2);
		result = result + "-";
		result = result + zeroPad(calendar.get(11), 2);
		result = result + "";
		result = result + zeroPad(calendar.get(12), 2);
		result = result + "";
		result = result + zeroPad(calendar.get(13), 2);
		result = result + ".";
		result = result + zeroPad(calendar.get(14), 3);

		return result;
	}

	private void onStartTransfer() {
		PassphraseDialogResult passphraseDialogResult = PassphraseDialog
				.run(this.shell);
		if (passphraseDialogResult == null)
			return;
		String passphrase = passphraseDialogResult.passphrase;

		String sourcePath = this.filePath.getText();
		Date now = new Date();
		String transferId = newTranferId(now);
		appendLogText("Transfer ID: " + transferId);
		PathUtils.createDirectory("log");

//		XMLLoggerTransferProperties xmlLoggerTransferProperties = new XMLLoggerTransferProperties(
//				transferId, sourcePath, now, this.host, this.port,
//				this.keystorePath);
		XMLLoggerTransferProperties xmlLoggerTransferProperties = new XMLLoggerTransferProperties(
				transferId, sourcePath, now, this.hostURL, this.keystorePath);

		this.xmlAllLogger = new XMLLogger(xmlLoggerTransferProperties, "log/"
				+ transferId + "." + "all.log.xml");
		this.xmlFailureLogger = new XMLLogger(xmlLoggerTransferProperties,
				"log/" + transferId + "." + "failures.log.xml");
		try {
			this.xmlAllLogger.open();
			this.xmlFailureLogger.open();
		} catch (IOException e) {
			showError(e);
			return;
		}
		setTitleText(Messages.getString("DeersWizard.Page2TitleTransferring"));

		this.start.setEnabled(false);
		this.viewLogButton.setEnabled(false);
		this.viewFailuresButton.setEnabled(false);
		this.mainAreaLayout.topControl = this.miniArea2;
		this.mainArea.layout();

		this.shell.setCursor(new Cursor(this.shell.getDisplay(), 1));

		this.totalNum.setText("");
		this.failedNum = (this.successNum = 0);
		this.failedNumText.setText("" + this.failedNum);
		this.successNumText.setText("" + this.successNum);
		this.bar.setMinimum(0);
		this.bar.setMaximum(0);
		this.bar.setSelection(0);

//		this.transferEngineThread = new CAC2DEERSTransferEngineThread(
//				sourcePath, this.keystorePath, this.host, this.port,
//				passphrase, new MyCAC2DEERSTransferEngineObserver(),
//				new MyCAC2DEERSTransferEngineThreadObserver());
		this.transferEngineThread = new CAC2DEERSTransferEngineThread(
				sourcePath, this.keystorePath, this.hostURL, 
				passphrase, new MyCAC2DEERSTransferEngineObserver(),
				new MyCAC2DEERSTransferEngineThreadObserver());
		this.transferEngineThread.start();

		this.cancelOrCloseButton.setText(Messages
				.getString("DeersWizard.ButtonCancel"));

		this.shell.setCursor(new Cursor(this.shell.getDisplay(), 0));
	}

	private void onCancelOrClose() {
		if (this.transferEngineThread != null) {
			this.shell.setCursor(new Cursor(this.shell.getDisplay(), 1));
			this.transferEngineThread.close();
			try {
				this.transferEngineThread.waitUntilClosed();
			} catch (InterruptedException e) {
				return;
			} finally {
				this.shell.setCursor(new Cursor(this.shell.getDisplay(), 0));
			}
			this.transferEngineThread = null;
			this.cancelOrCloseButton.setText(Messages
					.getString("DeersWizard.ButtonClose"));
		} else {
			this.shell.close();
		}
	}

	private static String logItemToString(LogItem logItem) {
		String result = "";
		result = result + logItem.getWhen();
		result = result + " ";
		result = result + LogItem.code2String(logItem.getCode());
		result = result + " ";

		if (logItem.getCode() == 5) {
			result = result + ": " + logItem.getDEERSTransReturnCodeStr();
		}
		if (logItem.getException() != null) {
			result = result + ": ";
			result = result + logItem.getException().getMessage();
		}
		if (logItem.getCode() == 1002) {
			result = result + " ";
			result = result + ": " + logItem.getCount();
		}
		return result;
	}

	private void onViewLog() {
		Program
				.launch(new File(HTMLLogTransformer
						.outputHTMLPath(this.xmlAllLogger.getPath()))
						.getAbsolutePath());
	}

	private void onViewFailures() {
		Program.launch(new File(HTMLLogTransformer
				.outputHTMLPath(this.xmlFailureLogger.getPath()))
				.getAbsolutePath());
	}

	public static void main(String[] args) throws FileNotFoundException,
			IOException {
		Display display = new Display();
		Shell shell = new Shell(display, 112);
		CAC2DEERSWizard wizard = new CAC2DEERSWizard(shell);
		wizard.run();

		shell.pack();
		shell.open();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}

		display.dispose();
	}

	class MyCAC2DEERSTransferEngineThreadObserver implements
			CAC2DEERSTransferEngineThreadObserver {
		MyCAC2DEERSTransferEngineThreadObserver() {
		}

		@Override
		public void onClosed() {
			CAC2DEERSWizard.this.shell.getDisplay().asyncExec(
					new CAC2DEERSWizard.EngineThreadClosedRunnable());
		}

		@Override
		public void onComplete() {
			CAC2DEERSWizard.this.shell.getDisplay().asyncExec(
					new CAC2DEERSWizard.EngineThreadCompleteRunnable());
		}

		@Override
		public void onException(Exception e) {
			CAC2DEERSWizard.this.shell.getDisplay().asyncExec(
					new CAC2DEERSWizard.EngineThreadExceptionRunnable(e));
		}

		@Override
		public void onIOException(IOException e) {
			CAC2DEERSWizard.this.shell.getDisplay().asyncExec(
					new CAC2DEERSWizard.EngineThreadExceptionRunnable(e));
		}

		@Override
		public void onCancelled() {
			CAC2DEERSWizard.this.shell.getDisplay().asyncExec(
					new CAC2DEERSWizard.EngineThreadCancelledRunnable());
		}
	}

	class EngineThreadExceptionRunnable implements Runnable {
		private final Exception e;

		public EngineThreadExceptionRunnable(Exception e) {
			this.e = e;
		}

		@Override
		public void run() {
			CAC2DEERSWizard.this.setTitleText(Messages
					.getString("DeersWizard.Page2TitleError"));
			CAC2DEERSWizard.this.viewFailuresButton.setEnabled(true);
			CAC2DEERSWizard.this.viewLogButton.setEnabled(true);

			CAC2DEERSWizard.this.showError(this.e);
		}
	}

	class EngineThreadCancelledRunnable implements Runnable {
		EngineThreadCancelledRunnable() {
		}

		@Override
		public void run() {
			try {
				CAC2DEERSWizard.this.setTitleText(Messages
						.getString("DeersWizard.Page2TitleCancelled"));

				CAC2DEERSWizard.this.viewFailuresButton.setEnabled(true);
				CAC2DEERSWizard.this.viewLogButton.setEnabled(true);
			} catch (Exception e) {
				CAC2DEERSWizard.this.showError(e);
			}
		}
	}

	class EngineThreadCompleteRunnable implements Runnable {
		EngineThreadCompleteRunnable() {
		}

		@Override
		public void run() {
			try {
				if (CAC2DEERSWizard.this.getFailedNum() > 0)
					CAC2DEERSWizard.this
							.setTitleText(Messages
									.getString("DeersWizard.Page2TitleCompletedWithFailures"));
				else {
					CAC2DEERSWizard.this
							.setTitleText(Messages
									.getString("DeersWizard.Page2TitleCompletedSuccessfully"));
				}
				CAC2DEERSWizard.this.viewFailuresButton.setEnabled(true);
				CAC2DEERSWizard.this.viewLogButton.setEnabled(true);
			} catch (Exception e) {
				CAC2DEERSWizard.this.showError(e);
			}
		}
	}

	class EngineThreadClosedRunnable implements Runnable {
		EngineThreadClosedRunnable() {
		}

		@Override
		public void run() {
			try {
				try {
					if (CAC2DEERSWizard.this.transferEngineThread != null)
						CAC2DEERSWizard.this.transferEngineThread
								.waitUntilClosed();
				} catch (InterruptedException e) {
					return;
				} finally {
					CAC2DEERSWizard.this.transferEngineThread = null;
				}
				CAC2DEERSWizard.this.cancelOrCloseButton.setText(Messages
						.getString("DeersWizard.ButtonClose"));
				try {
					CAC2DEERSWizard.this.xmlAllLogger.close();
					CAC2DEERSWizard.this.xmlFailureLogger.close();
					HTMLLogTransformer
							.transform(CAC2DEERSWizard.this.xmlAllLogger
									.getPath());
					HTMLLogTransformer
							.transform(CAC2DEERSWizard.this.xmlFailureLogger
									.getPath());
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			} catch (Exception e) {
				CAC2DEERSWizard.this.showError(e);
			}
		}
	}

	class MyCAC2DEERSTransferEngineObserver implements
			CAC2DEERSTransferEngineObserver {
		MyCAC2DEERSTransferEngineObserver() {
		}

		@Override
		public void onLogItem(LogItem logItem) {
			CAC2DEERSWizard.this.shell.getDisplay().asyncExec(
					new CAC2DEERSWizard.LogItemRunnable(logItem));
		}
	}

	class LogItemRunnable implements Runnable {
		private final LogItem logItem;

		public LogItemRunnable(LogItem logItem) {
			this.logItem = logItem;
		}

		@Override
		public void run() {
			CAC2DEERSWizard.this.xmlAllLogger.appendLogItem(this.logItem);
			if (LogItem.isFailedRecord(this.logItem.getCode())) {
				CAC2DEERSWizard.this.xmlFailureLogger
						.appendLogItem(this.logItem);
			}
			CAC2DEERSWizard.this.appendLogText(CAC2DEERSWizard
					.logItemToString(logItem));

			if (this.logItem.getCode() == 1002) {
				CAC2DEERSWizard.this.totalNum.setText(""
						+ this.logItem.getCount());
				CAC2DEERSWizard.this.bar.setMinimum(0);
				CAC2DEERSWizard.this.bar.setMaximum(this.logItem.getCount());
				CAC2DEERSWizard.this.bar.setSelection(0);
			}
			if (LogItem.isFailedRecord(this.logItem.getCode())) {
				CAC2DEERSWizard.this.incrementFailedNum();
				CAC2DEERSWizard.this.bar.setSelection(CAC2DEERSWizard.this.bar
						.getSelection() + 1);
			} else if (this.logItem.getCode() == 0) {
				CAC2DEERSWizard.this.incrementSuccessNum();
				CAC2DEERSWizard.this.bar.setSelection(CAC2DEERSWizard.this.bar
						.getSelection() + 1);
			}
		}
	}
}