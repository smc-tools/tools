package gov.nsa.cac2deers;

import gov.nsa.utils.synchronization.CloseableThread;

import java.io.IOException;


public class CAC2DEERSTransferEngineThread extends CloseableThread {
	private final String path;
	private final String keystorePath;
	//private final String host;
	private final String hostURL;
	private final String passphrase;
	//private final int port;
	private final CAC2DEERSTransferEngineObserver engineObserver;
	private final CAC2DEERSTransferEngineThreadObserver threadObserver;
	private final CAC2DEERSTransferEngine engine = new CAC2DEERSTransferEngine();

//	public CAC2DEERSTransferEngineThread(String path, String keystorePath,
//			String host, int port, String passphrase,
//			CAC2DEERSTransferEngineObserver engineObserver,
//			CAC2DEERSTransferEngineThreadObserver threadObserver) {
	public CAC2DEERSTransferEngineThread(String path, String keystorePath,
			String hostURL, String passphrase,
			CAC2DEERSTransferEngineObserver engineObserver,
			CAC2DEERSTransferEngineThreadObserver threadObserver) {	
		super(Thread.currentThread().getThreadGroup(),
				"CAC2DEERSTransferEngineThread");
		this.path = path;
		this.keystorePath = keystorePath;
		this.hostURL = hostURL;
//		this.host = host;
//		this.port = port;
		this.passphrase = passphrase;
		this.engineObserver = engineObserver;
		this.threadObserver = threadObserver;
	}

	@Override
	public void close() {
		setClosing();
		this.engine.cancel();
	}

	@Override
	public void run() {
		try {
//			if (!this.engine.transferFile(this.path, this.keystorePath,
//					this.host, this.port, this.passphrase, this.engineObserver))
			if (!this.engine.transferFile(this.path, this.keystorePath,
					this.hostURL, this.passphrase, this.engineObserver))
				this.threadObserver.onCancelled();
			else
				this.threadObserver.onComplete();
		} catch (IOException e) {
			this.threadObserver.onIOException(e);
		} catch (Exception e) {
			this.threadObserver.onException(e);
		} finally {
			this.threadObserver.onClosed();
			setClosed();
		}
	}
}