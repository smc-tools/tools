package gov.nsa.cac2deers;

import java.io.IOException;

public interface CAC2DEERSTransferEngineThreadObserver {
	void onIOException(IOException paramIOException);

	void onException(Exception paramException);

	void onComplete();

	void onCancelled();

	void onClosed();
}