package gov.nsa.cac2deers;

import gov.nsa.cac.CACRecord;
import gov.nsa.deers.DEERSTransferRecord;


public interface CAC2DEERSRecordFileConverterObserver {
	void onDEERSTransferRecord(DEERSTransferRecord paramDEERSTransferRecord);

	void onCACRecordFormatException(String paramString,
			gov.nsa.cac.FormatException paramFormatException);

	void onConverterFormatException(CACRecord paramCACRecord,
			gov.nsa.cac.FormatException paramFormatException);

	void onConverterFormatException(CACRecord paramCACRecord,
			gov.nsa.deers.FormatException paramFormatException);

	void onEOS();
}