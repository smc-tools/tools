package gov.nsa.cac2deers.gui;

import java.util.Date;

public class XMLLoggerTransferProperties {
	private final String transferId;
	private final String sourcePath;
	private final Date logDate;
	private final String hostURL;
//	private final String host;
//	private final int port;
	private final String keystorePath;

//	public XMLLoggerTransferProperties(String transferId, String sourcePath,
//			Date logDate, String host, int port, String keystorePath) {
	public XMLLoggerTransferProperties(String transferId, String sourcePath,
			Date logDate, String hostURL, String keystorePath) {
		this.transferId = transferId;
		this.sourcePath = sourcePath;
		this.logDate = logDate;
		this.hostURL = hostURL;
//		this.host = host;
//		this.port = port;
		this.keystorePath = keystorePath;
	}

//	public String getHost() {
//		return this.host;
//	}
	
	public String getHostURL() {
		return this.hostURL;
	}

	public String getKeystorePath() {
		return this.keystorePath;
	}

	public Date getLogDate() {
		return this.logDate;
	}

//	public int getPort() {
//		return this.port;
//	}

	public String getSourcePath() {
		return this.sourcePath;
	}

	public String getTransferId() {
		return this.transferId;
	}
}