package gov.nsa.cac2deers;

import gov.nsa.cac.CACRecord;
import gov.nsa.cac.CACRecordFileParserObserver;
import gov.nsa.deers.DEERSTransferRecord;


class CAC2DEERSConvertingObserver implements CACRecordFileParserObserver {
	private CAC2DEERSRecordFileConverterObserver observer;

	public CAC2DEERSConvertingObserver(
			CAC2DEERSRecordFileConverterObserver observer) {
		this.observer = observer;
	}

	@Override
	public void onCACRecord(CACRecord record) {
		try {
			DEERSTransferRecord transferRecord = CAC2DEERSRecordConverter
					.convert(record);
			this.observer.onDEERSTransferRecord(transferRecord);
		} catch (gov.nsa.deers.FormatException e) {
			this.observer.onConverterFormatException(record, e);
		} catch (gov.nsa.cac.FormatException e) {
			this.observer.onConverterFormatException(record, e);
		}
	}

	@Override
	public void onCACRecordFormatException(String raw,
			gov.nsa.cac.FormatException e) {
		this.observer.onCACRecordFormatException(raw, e);
	}

	@Override
	public void onEOS() {
		this.observer.onEOS();
	}
}