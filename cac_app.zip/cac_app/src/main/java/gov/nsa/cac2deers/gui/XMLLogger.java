package gov.nsa.cac2deers.gui;

import gov.nsa.cac2deers.LogItem;
import gov.nsa.deers.FormatException;
import gov.nsa.xmlgen.XMLBuffer;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;


public class XMLLogger
{
  private final String path;
  private OutputStream out;
  private XMLBuffer b = new XMLBuffer();
  private final XMLLoggerTransferProperties rootNodeProps;
  private int lastPos = 0;

  public XMLLogger(XMLLoggerTransferProperties rootNodeProps, String path)
  {
    this.rootNodeProps = rootNodeProps;
    this.path = path;
  }

  public String getPath()
  {
    return this.path;
  }

  private void mark()
  {
    this.lastPos = this.b.length();
  }

  private void write() {
    int currentPos = this.b.length();

    String s = this.b.substring(this.lastPos, currentPos);
    try
    {
      this.out.write(s.getBytes());
      this.out.flush();
    }
    catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public void open() throws IOException
  {
    this.out = new FileOutputStream(this.path);

    mark();
    this.b = new XMLBuffer();
    this.b.beginOpenTag("XMLLog");
    this.b.attributeAssignment("transferId", this.rootNodeProps.getTransferId());
    this.b.attributeAssignment("sourcePath", "" + this.rootNodeProps.getSourcePath());
    this.b.attributeAssignment("logDateStr", "" + this.rootNodeProps.getLogDate());
    this.b.attributeAssignment("keystorePath", "" + this.rootNodeProps.getKeystorePath());
    this.b.attributeAssignment("hostURL", "" + this.rootNodeProps.getHostURL());
//    this.b.attributeAssignment("host", "" + this.rootNodeProps.getHost());
//    this.b.attributeAssignment("port", "" + this.rootNodeProps.getPort());

    this.b.endOpenTag();
    this.b.raw('\n');
    write();
  }

  public void appendLogItem(LogItem logItem) {
    mark();
    this.b.openTag("LogItem");
    this.b.raw('\n');

    int tabs = 0;
    tabs++;
    this.b.repeatRaw('\t', tabs);
    this.b.beginOpenTag("When");
    this.b.attributeAssignment("dateStr", "" + logItem.getWhen());

    this.b.endOpenCloseTag();
    this.b.raw('\n');
    tabs--;

    tabs++;
    this.b.repeatRaw('\t', tabs);
    this.b.beginOpenTag("Code");
    this.b.attributeAssignment("code", "" + logItem.getCode());

    this.b.attributeAssignment("codeStr", "" + LogItem.code2String(logItem.getCode()));

    this.b.attributeAssignment("isFailedRecord", "" + LogItem.isFailedRecord(logItem.getCode()));

    this.b.endOpenCloseTag();
    tabs--;
    this.b.raw('\n');

    if (logItem.getException() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);

      this.b.beginOpenTag("Exception");
      this.b.attributeAssignment("message", "" + logItem.getException().getMessage());
      this.b.raw('\n'); this.b.repeatRaw('\t', tabs);
      this.b.attributeAssignment("class", "" + logItem.getException().getClass().getName());
      this.b.raw('\n'); this.b.repeatRaw('\t', tabs);

      this.b.endOpenCloseTag();
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getRawInput() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);
      this.b.openTag_Text_CloseTag("rawInput", logItem.getRawInput());
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getCode() == 1002)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);
      this.b.openTag_Text_CloseTag("count", "" + logItem.getCount());
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getCacRecord() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);
      this.b.openTag_Text_CloseTag("CACRecord", "" + logItem.getCacRecord());
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getDeersRecord() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);
      this.b.openTag_Text_CloseTag("DEERSRecord", "" + logItem.getDeersRecord());
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getDeersRecord() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);
      this.b.openTag("DEERSRecordFields");
      this.b.raw('\n');

      for (int i = 0; i < logItem.getDeersRecord().getRecordDescriptor().getNumFields(); i++)
      {
        String columnName = logItem.getDeersRecord().getRecordDescriptor().getColumnNames()[i];
        String value = null;
        try
        {
          value = logItem.getDeersRecord().getRawField(columnName);
        }
        catch (FormatException e) {
          value = "!" + e.getMessage() + "!";
        }

        tabs++;
        this.b.repeatRaw('\t', tabs);
        this.b.beginOpenTag("Field");
        this.b.attributeAssignment("columnName", columnName);
        if (value != null)
          this.b.attributeAssignment("value", value);
        this.b.endOpenCloseTag();
        this.b.raw('\n');
        tabs--;
      }

      this.b.repeatRaw('\t', tabs);
      this.b.closeTag("DEERSRecordFields");
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getAck() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);
      this.b.openTag_Text_CloseTag("Ack", "" + logItem.getAck());
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getAck() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);
      this.b.openTag("AckFields");
      this.b.raw('\n');
      for (int i = 0; i < logItem.getAck().getRecordDescriptor().getNumFields(); i++)
      {
        String columnName = logItem.getAck().getRecordDescriptor().getColumnNames()[i];
        String value = null;
        try
        {
          value = logItem.getAck().getRawField(columnName);
        }
        catch (FormatException e) {
          value = "!" + e.getMessage() + "!";
        }

        tabs++;
        this.b.repeatRaw('\t', tabs);
        this.b.beginOpenTag("Field");
        this.b.attributeAssignment("columnName", columnName);
        if (value != null)
          this.b.attributeAssignment("value", value);
        this.b.endOpenCloseTag();
        this.b.raw('\n');
        tabs--;
      }

      this.b.repeatRaw('\t', tabs);
      this.b.closeTag("AckFields");
      this.b.raw('\n');
      tabs--;
    }

    if (logItem.getAck() != null)
    {
      tabs++;
      this.b.repeatRaw('\t', tabs);

      this.b.beginOpenTag("AckMessages");
      this.b.attributeAssignment("transReturnStatusCodeStr", "" + logItem.getDEERSTransReturnStatusCodeStr());
      this.b.raw('\n'); this.b.repeatRaw('\t', tabs);
      this.b.attributeAssignment("transReturnCodeStr", "" + logItem.getDEERSTransReturnCodeStr());
      this.b.raw('\n'); this.b.repeatRaw('\t', tabs);
      this.b.endOpenCloseTag();
      this.b.raw('\n');
      tabs--;
    }

    this.b.closeTag("LogItem");
    this.b.raw('\n');
    this.b.raw('\n');
    write();
  }

  public void close() throws IOException {
    mark();
    this.b.closeTag("XMLLog");
    write();
    this.out.close();
  }

  public String toXMLString() {
    return this.b.toString();
  }

  public String toValidIntermediateXMLString()
  {
    XMLBuffer b2 = new XMLBuffer();
    b2.raw(this.b.toString());
    b2.closeTag("XMLLog");
    return this.b.toString();
  }
}