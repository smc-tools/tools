package gov.nsa.cac2deers;

import gov.nsa.cac.CACRecord;
import gov.nsa.deers.DEERSTransferRecord;
import gov.nsa.deers.FormatException;
import gov.nsa.deers.Header;
import gov.nsa.deers.ReturnCodeMessages;

import java.util.Date;


public class LogItem {
	private Date when;
	private int code;
	public static final int SUCCESS = 0;
	public static final int CAC_RECORD_FORMAT_EXCEPTION = 1;
	public static final int CONVERTER_FORMAT_EXCEPTION_CAC = 2;
	public static final int CONVERTER_FORMAT_EXCEPTION_DEERS = 3;
	public static final int UPLOADER_FORMAT_EXCEPTION = 4;
	public static final int UPLOADER_NEGATIVE_ACK = 5;
	public static final int BEGIN = 1000;
	public static final int END = 1001;
	public static final int COUNT = 1002;
	public static final int CANCELLED = 1003;
	private String rawInput;
	private CACRecord cacRecord;
	private DEERSTransferRecord deersRecord;
	private Header ack;
	private Exception exception;
	private int count;

	public static boolean isFailedRecord(int code) {
		switch (code) {
		case 0:
		case 1000:
		case 1001:
		case 1002:
		case 1003:
			return false;
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			return true;
		}
		throw new IllegalArgumentException();
	}

	public static String code2String(int code) {
		switch (code) {
		case 0:
			return "Success";
		case 1:
			return "Error parsing CAC input";
		case 2:
			return "Error extracting data from parsed CAC input";
		case 3:
			return "Error converting data to DEERS format";
		case 4:
			return "Format error talking to DEERS";
		case 5:
			return "DEERS returned a negative acknowledgment";
		case 1000:
			return "Begin transfer";
		case 1001:
			return "End transfer";
		case 1003:
			return "Transfer cancelled";
		case 1002:
			return "Record count obtained";
		}
		return null;
	}

	public LogItem(int code, String rawInput, CACRecord cacRecord,
			DEERSTransferRecord deersRecord, Header ack, Exception exception) {
		this.when = new Date(System.currentTimeMillis());
		this.code = code;
		this.rawInput = rawInput;
		this.cacRecord = cacRecord;
		this.deersRecord = deersRecord;
		this.ack = ack;
		this.exception = exception;
		this.count = 0;
	}

	public LogItem(int code, int count) {
		this.when = new Date(System.currentTimeMillis());
		this.code = code;
		this.count = count;
	}

	public Header getAck() {
		return this.ack;
	}

	public CACRecord getCacRecord() {
		return this.cacRecord;
	}

	public int getCode() {
		return this.code;
	}

	public DEERSTransferRecord getDeersRecord() {
		return this.deersRecord;
	}

	public Exception getException() {
		return this.exception;
	}

	public String getRawInput() {
		return this.rawInput;
	}

	public int getCount() {
		return this.count;
	}

	public Date getWhen() {
		return this.when;
	}

	private String getAckRawField(String field) {
		if (getAck() == null) {
			return null;
		}
		try {
			return getAck().getRawField(field);
		} catch (FormatException e) {
			e.printStackTrace();
		}
		return null;
	}

	public String getDEERSTransTypeCode() {
		return getAckRawField("TXN_TYP_CD");
	}

	public String getDEERSTransReturnStatusCode() {
		return getAckRawField("TXN_RT_STAT_CD");
	}

	public String getDEERSTransReturnCode() {
		return getAckRawField("TXN_RT_CD");
	}

	public String getDEERSTransReturnStatusCodeStr() {
		String s1 = getDEERSTransReturnStatusCode();
		if (s1 == null)
			return null;
		return ReturnCodeMessages.getReturnStatusCodeStr(s1);
	}

	public String getDEERSTransReturnCodeStr() {
		String s1 = getDEERSTransReturnStatusCode();
		String s2 = getDEERSTransReturnCode();
		if ((s1 == null) || (s2 == null))
			return null;
		return ReturnCodeMessages.getReturnCodeStr(s1, s2);
	}
}