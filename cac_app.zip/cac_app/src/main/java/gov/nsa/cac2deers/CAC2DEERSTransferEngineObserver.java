package gov.nsa.cac2deers;

public interface CAC2DEERSTransferEngineObserver {
	void onLogItem(LogItem paramLogItem);
}