package gov.nsa.cac2deers;

import gov.nsa.cac.CACRecord;
import gov.nsa.deers.BatchUploader;
import gov.nsa.deers.BatchUploaderObserver;
import gov.nsa.deers.DEERSTransferRecord;
import gov.nsa.deers.Header;
import gov.nsa.utils.synchronization.SynchronizedBoolean;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;


public class CAC2DEERSTransferEngine {
	private Collection<DEERSTransferRecord> deersRecords;
	private CAC2DEERSTransferEngineObserver observer;
	private BatchUploader batchUploader;
	private SynchronizedBoolean cancelled;

	public CAC2DEERSTransferEngine() {
		this.cancelled = new SynchronizedBoolean(false);
	}

	public void cancel() {
		synchronized (this.cancelled) {
			this.cancelled.setValue(true);

			if (this.batchUploader != null)
				this.batchUploader.cancel();
		}
	}

//	public boolean transferFile(String path, String keystorePath, String host,
//			int port, String passphrase,
//			CAC2DEERSTransferEngineObserver observer) throws IOException {
	public boolean transferFile(String path, String keystorePath, String hostURL, String passphrase,
			CAC2DEERSTransferEngineObserver observer) throws IOException {
		this.observer = observer;
		this.deersRecords = new ArrayList<DEERSTransferRecord>();
		log(new LogItem(1000, null, null, null, null, null));
		CAC2DEERSRecordFileConverter.parseFile(path,
				new MyCAC2DEERSRecordFileConverterObserver());
		int recordCount = this.deersRecords.size();
		log(new LogItem(1002, recordCount));

		if (recordCount > 0) {
			synchronized (this.cancelled) {
				if (this.cancelled.getValue())
					return false;
				this.batchUploader = new BatchUploader();
			}

//			if (!this.batchUploader.upload(keystorePath, host, port,
//					passphrase, this.deersRecords,
//					new MyBatchUploaderObserver())) {
//				log(new LogItem(1003, null, null, null, null, null));
//				return false;
//			}
			if (!this.batchUploader.upload(keystorePath, hostURL,
					passphrase, this.deersRecords,
					new MyBatchUploaderObserver())) {
				log(new LogItem(1003, null, null, null, null, null));
				return false;
			}
		}
		log(new LogItem(1001, null, null, null, null, null));
		return true;
	}

	private void log(LogItem logItem) {
		this.observer.onLogItem(logItem);
	}

	class MyBatchUploaderObserver implements BatchUploaderObserver {
		MyBatchUploaderObserver() {
		}

		@Override
		public void onFormatException(Header ack, DEERSTransferRecord rec,
				gov.nsa.deers.FormatException e) {
			CAC2DEERSTransferEngine.this.log(new LogItem(4, null, null, rec,
					ack, e));
		}

		@Override
		public void onNegativeAck(Header ack, DEERSTransferRecord rec) {
			CAC2DEERSTransferEngine.this.log(new LogItem(5, null, null, rec,
					ack, null));
		}

		@Override
		public void onPositiveAck(Header ack, DEERSTransferRecord rec) {
			CAC2DEERSTransferEngine.this.log(new LogItem(0, null, null, rec,
					ack, null));
		}
	}

	class MyCAC2DEERSRecordFileConverterObserver implements
			CAC2DEERSRecordFileConverterObserver {
		MyCAC2DEERSRecordFileConverterObserver() {
		}

		@Override
		public void onCACRecordFormatException(String raw,
				gov.nsa.cac.FormatException e) {
			CAC2DEERSTransferEngine.this.log(new LogItem(1, raw, null, null,
					null, e));
		}

		@Override
		public void onConverterFormatException(CACRecord record,
				gov.nsa.deers.FormatException e) {
			CAC2DEERSTransferEngine.this.log(new LogItem(2, null, record, null,
					null, e));
		}

		@Override
		public void onConverterFormatException(CACRecord record,
				gov.nsa.cac.FormatException e) {
			CAC2DEERSTransferEngine.this.log(new LogItem(3, null, record, null,
					null, e));
		}

		@Override
		public void onDEERSTransferRecord(DEERSTransferRecord record) {
			CAC2DEERSTransferEngine.this.deersRecords.add(record);
		}

		@Override
		public void onEOS() {
		}
	}
}