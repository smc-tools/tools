package gov.nsa.cac2deers.gui;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

public final class Messages {
	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle
			.getBundle("gov.nsa.cac2deers.gui.messages");

	public static String getString(String key) {
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
		}
		return '!' + key + '!';
	}
}