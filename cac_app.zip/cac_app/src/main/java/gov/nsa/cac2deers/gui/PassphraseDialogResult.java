package gov.nsa.cac2deers.gui;

public class PassphraseDialogResult
{
  public String passphrase;

  public PassphraseDialogResult(String password)
  {
    this.passphrase = password;
  }
}