package gov.nsa.deers;

import java.io.IOException;

public class FormattedConnection {
	//private Connection connection;
	private CivUptConnection civUptConn;

//	public FormattedConnection(Connection connection) {
//		this.connection = connection;
//	}
//	
	public FormattedConnection(CivUptConnection civUptConn) {
		this.civUptConn = civUptConn;
	}

	public void sendReceive(Record rec, Record resp) throws IOException,
			FormatException {
		String sTR = rec.toString();
		//String sResult = this.connection.sendReceive(sTR);
		String sResult = this.civUptConn.sendReceive(sTR);

		resp.setFrom(sResult);
	}
}