package gov.nsa.deers;

public class DEERSTransferRecord extends Header {
	public static final String SPN_PN_ID = "SPN_PN_ID";
	public static final String SPN_PN_ID_TYP_CD = "SPN_PN_ID_TYP_CD";
	public static final String PN_LST_NM = "PN_LST_NM";
	public static final String PN_1ST_NM = "PN_1ST_NM";
	public static final String PN_MID_NM = "PN_MID_NM";
	public static final String PN_CDNCY_NM = "PN_CDNCY_NM";
	public static final String PN_BRTH_DT = "PN_BRTH_DT";
	public static final String PN_SEX_CD = "PN_SEX_CD";
	public static final String US_CTZP_STAT_CD = "US_CTZP_STAT_CD";
	public static final String LOC_CTRY_CD = "LOC_CTRY_CD";
	public static final String PNL_CAT_CD = "PNL_CAT_CD";
	public static final String PNL_BGN_DT = "PNL_BGN_DT";
	public static final String PNL_PE_DT = "PNL_PE_DT";
	public static final String PNL_PEDC_CD = "PNL_PEDC_CD";
	public static final String PNL_TERM_DT = "PNL_TERM_DT";
	public static final String PNL_TRSN_CD = "PNL_TRSN_CD";
	public static final String USGVT_AGCY_CD = "USGVT_AGCY_CD";
	public static final String PNL_TXN_TYP_CD = "PNL_TXN_TYP_CD";
	public static final String PNL_TXN_DT = "PNL_TXN_DT";
	public static final String PAY_PLN_CD = "PAY_PLN_CD";
	public static final String PG_CD = "PG_CD";
	public static final String PG_DT = "PG_DT";
	public static final String UNIT_ID_CD = "UNIT_ID_CD";
	public static final RecordDescriptor recordDescriptor = new RecordDescriptor(
			HeaderFieldDescriptors.headerFieldDescriptors,
			new FieldDescriptor[] {
					new FieldDescriptor("Sponsor Key", 13, 1,
							"Sponsor Person Identifier", 9, "SPN_PN_ID", 0),
					new FieldDescriptor("Sponsor Key", 14, 2,
							"Sponsor Person Identifier Type Code", 1,
							"SPN_PN_ID_TYP_CD", 0),
					new FieldDescriptor("Sponsor Key", 15, 15,
							"Person Last Name", 26, "PN_LST_NM", 1),
					new FieldDescriptor("Sponsor Key", 16, 16,
							"Person First Name", 20, "PN_1ST_NM", 1),
					new FieldDescriptor("Sponsor Key", 17, 17,
							"Person Middle Name", 20, "PN_MID_NM", 1),
					new FieldDescriptor("Sponsor Key", 18, 18,
							"Person Cadency Name", 4, "PN_CDNCY_NM", 1),
					new FieldDescriptor("Sponsor Key", 19, 19,
							"Person Birth Date", 8, "PN_BRTH_DT", 2),
					new FieldDescriptor("Sponsor Key", 20, 20,
							"Person Sex Code", 1, "PN_SEX_CD", 0),
					new FieldDescriptor("Sponsor Key", 21, 21,
							"Person Citizen Status Code", 1, "US_CTZP_STAT_CD",
							0),
					new FieldDescriptor("Location", 22, 1,
							"Location Country Code", 2, "LOC_CTRY_CD", 0),
					new FieldDescriptor("Personnel", 23, 1,
							"Personnel Category Code", 1, "PNL_CAT_CD", 0),
					new FieldDescriptor("Personnel", 24, 2,
							"Personnel Begin Date", 8, "PNL_BGN_DT", 2),
					new FieldDescriptor("Personnel", 25, 3,
							"Personnel Projected End Date", 8, "PNL_PE_DT", 2),
					new FieldDescriptor("Personnel", 26, 4,
							"Personnel Projected End Code", 1, "PNL_PEDC_CD", 0),
					new FieldDescriptor("Personnel", 27, 5,
							"Personnel Termination Date", 8, "PNL_TERM_DT", 2),
					new FieldDescriptor("Personnel", 28, 6,
							"Personnel Termination Reason Code", 1,
							"PNL_TRSN_CD", 0),
					new FieldDescriptor("Personnel", 29, 7,
							"Government Agency Code", 4, "USGVT_AGCY_CD", 0),
					new FieldDescriptor("Personnel", 30, 8,
							"Personnel Transaction Type Code", 1,
							"PNL_TXN_TYP_CD", 0),
					new FieldDescriptor("Personnel", 31, 9,
							"Personnel Transaction Date", 8, "PNL_TXN_DT", 2),
					new FieldDescriptor("Pay Grade", 32, 1, "Pay Plan Code", 5,
							"PAY_PLN_CD", 0),
					new FieldDescriptor("Pay Grade", 33, 2, "Pay Grade Code",
							2, "PG_CD", 0),
					new FieldDescriptor("Pay Grade", 34, 3, "Pay Grade Date",
							8, "PG_DT", 2),
					new FieldDescriptor("Unit Id", 35, 1,
							"Assigned Unit Identification Code", 8,
							"UNIT_ID_CD", 0) });

	public DEERSTransferRecord() {
		super(recordDescriptor);
	}

	public DEERSTransferRecord(String value) throws FormatException {
		super(recordDescriptor, value);
	}
}