package gov.nsa.deers;

import java.io.PrintStream;

import org.apache.commons.lang3.StringUtils;

public class RecordDumper {
	public static void dumpRecord(Record record, PrintStream ps)
			throws FormatException {
		StringBuffer b = new StringBuffer();
		dumpRecord(record, b);
		ps.println(record);
	}

	public static void dumpRecord(Record record, StringBuffer b)
			throws FormatException {
		String[] columnNames = record.getRecordDescriptor().getColumnNames();
		for (int i = 0; i < columnNames.length; i++) {
			String columnName = columnNames[i];
			// String paddedColumnName = columnName;
			b.append(pad(columnName, 20)
					+ pad(new StringBuffer().append("[").append(
							record.getRawField(columnName)).append("]")
							.toString(), 30)
					+ pad(
							new StringBuffer().append("{").append(
									record.getValue(columnName)).append("}")
									.toString(), 20));
			b.append("\n");
		}
	}

	public static String pad(String s, int len) {
		return StringUtils.rightPad(s, len, " ");
	}
}