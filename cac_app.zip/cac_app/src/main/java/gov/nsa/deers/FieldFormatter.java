package gov.nsa.deers;

import org.apache.commons.lang3.StringUtils;

public class FieldFormatter {
	public static String formatTrailingSpacePaddedString(String value, int len)
			throws FormatException {
		String s = value;
		if (s.length() > len)
			throw new FormatException(
					"String is too large to fit in field of length " + len
							+ ": [" + value + "]");
		return StringUtils.rightPad(s, len, " ");
	}

	public static String formatZeroPaddedString(int value, int len)
			throws FormatException {
		String s = Integer.toString(value);
		if (s.length() > len)
			throw new FormatException(
					"Number is too large to fit in field of length " + len
							+ ": " + value);
		return StringUtils.leftPad(s, len, "0");
	}

	public static int parseZeroPaddedString(String s) throws FormatException {
		try {
			return Integer.parseInt(s);
		} catch (NumberFormatException e) {
			throw new FormatException("Expected number", e);
		}
	}

	public static String formatDate(Date value) throws FormatException {
		return formatZeroPaddedString(value.getYear(), 4)
				+ formatZeroPaddedString(value.getMonth(), 2)
				+ formatZeroPaddedString(value.getDay(), 2);
	}

	public static String formatTime(Time value) throws FormatException {
		return formatZeroPaddedString(value.getHour(), 2)
				+ formatZeroPaddedString(value.getMin(), 2)
				+ formatZeroPaddedString(value.getSec(), 2);
	}

	public static Date parseDate(String value) throws FormatException {
		if (value.length() != 8) {
			throw new FormatException("Expected date field to have length 8");
		}
		String yearStr = value.substring(0, 4);
		String monthStr = value.substring(4, 6);
		String dayStr = value.substring(6, 8);
		try {
			int year = parseZeroPaddedString(yearStr);
			int month = parseZeroPaddedString(monthStr);
			int day = parseZeroPaddedString(dayStr);
			return new Date(year, month, day);
		} catch (FormatException e) {
			throw new FormatException("Expected number in date field", e);
		}
	}

	public static Time parseTime(String value) throws FormatException {
		if (value.length() != 6) {
			throw new FormatException("Expected time field to have length 6");
		}
		String hourStr = value.substring(0, 2);
		String minuteStr = value.substring(2, 4);
		String secondStr = value.substring(4, 6);
		try {
			int hour = parseZeroPaddedString(hourStr);
			int minute = parseZeroPaddedString(minuteStr);
			int second = parseZeroPaddedString(secondStr);
			return new Time(hour, minute, second);
		} catch (FormatException e) {
			throw new FormatException("Expected number in time field", e);
		}
	}
}