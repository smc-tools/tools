package gov.nsa.deers;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.apache.log4j.Logger;

public class Connection {
	static Logger logger = Logger.getLogger(Connection.class.getName());
	private String host;
	private int port;
	private SSLSocketFactory factory;

	public Connection(String keystorePath, String host, int port,
			String passphrase) {
		this.host = host;
		this.port = port;

		System.setProperty("javax.net.ssl.trustStore", keystorePath);

		this.factory = null;
		try {
			char[] passphraseChars = passphrase.toCharArray();

			SSLContext ctx = SSLContext.getInstance("TLS");
			KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
			KeyStore ks = KeyStore.getInstance("JKS");

			ks.load(new FileInputStream(keystorePath), passphraseChars);

			kmf.init(ks, passphraseChars);
			ctx.init(kmf.getKeyManagers(), null, null);

			this.factory = ctx.getSocketFactory();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public String sendReceive(String sTR) throws IOException {
		// String sReturn = "";
		int iLength = 0;
		char[] chReturn = new char[14];
		String sOutput = "";
		int iSize = 0;
		StringBuffer sbOutTRSize = new StringBuffer("000000");

		String sPreamble = "DSC1,  $MACHINE CERT    ";

		SSLSocket socket = (SSLSocket) this.factory.createSocket(this.host,
				this.port);

		socket.setKeepAlive(true);

		socket.startHandshake();

		BufferedReader br = new BufferedReader(new InputStreamReader(socket
				.getInputStream()));
		PrintWriter pw = new PrintWriter(socket.getOutputStream());

		logger.debug("Sending: " + sPreamble);
		pw.print(sPreamble);
		pw.flush();

		iLength = br.read(chReturn, 0, 14);
		sOutput = String.valueOf(chReturn);
		logger.debug("Length: " + iLength + " sOutput Returned: " + sOutput);
		if (sOutput.equals("READY UNIKIX01")) {
			sbOutTRSize.replace(sbOutTRSize.length()
					- ("" + sTR.length()).length(), sbOutTRSize.length(), ""
					+ sTR.length());
			logger.debug("Sending: " + sbOutTRSize.toString());
			pw.print(sbOutTRSize.toString());
			pw.flush();

			logger.debug("Sending: " + sTR);
			pw.print(sTR);
			pw.flush();

			chReturn = new char[6];
			iLength = br.read(chReturn, 0, 6);
			if (iLength < 0)
				throw new IOException(
						"End of stream - expected 6-byte message length");
			sOutput = String.valueOf(chReturn);
			logger
					.debug("Length: " + iLength + " sOutput Returned: "
							+ sOutput);
			try {
				iSize = Integer.parseInt(sOutput);
			} catch (NumberFormatException e) {
				throw new IOException("Expected number: " + sOutput);
			}

			chReturn = new char[iSize];
			iLength = br.read(chReturn, 0, iSize);
			if (iLength < 0)
				throw new IOException("End of stream - expected message body");
			sOutput = String.valueOf(chReturn);
			logger
					.debug("Length: " + iLength + " sOutput Returned: "
							+ sOutput);
		} else {
			throw new IOException("expected READY UNIKIX01");
		}

		socket.close();
		return sOutput;
	}
}