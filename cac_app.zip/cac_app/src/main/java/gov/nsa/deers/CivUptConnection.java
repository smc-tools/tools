package gov.nsa.deers;

import java.io.BufferedReader;
//import java.io.DataOutputStream;
//import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
//import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
//import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyStore;
import java.security.SecureRandom;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;

import org.apache.log4j.Logger;

public class CivUptConnection {
	private static final Logger logger = Logger
			.getLogger(CivUptConnection.class.getName());

	private String hostURL;
	private SSLSocketFactory factory;

	public CivUptConnection(String keystorePath, String hostURL,
			String passphrase) {
		this.hostURL = hostURL;
		logger.debug("keystore path: " + keystorePath);
		System.setProperty("javax.net.ssl.trustStore", keystorePath);

		this.factory = null;
		try {
			KeyManagerFactory keyManagerFactory = KeyManagerFactory
					.getInstance("SunX509");
			KeyStore keyStore = KeyStore.getInstance("JKS");
			keyStore.load(new FileInputStream(keystorePath), passphrase.toCharArray());
			keyManagerFactory.init(keyStore, passphrase.toCharArray());
			SSLContext context = SSLContext.getInstance("TLS");
			context.init(keyManagerFactory.getKeyManagers(), null,
					new SecureRandom());
			this.factory = context.getSocketFactory();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public String sendReceive(String sTR) throws IOException {
		HttpsURLConnection connection = null;
		String requestParams = "msg=" + sTR;
		try {
			// URL url = new URL("https://localhost:15212/civupt/TRServlet");
			// URL url = new
			// URL("http://wt1.int.dmdc.osd.mil/civupt/TRServlet");
			// URL url = new URL("http://localhost:15211/civupt/TRServlet");
			logger.debug("\nSending 'POST' request to URL : " + hostURL);
			URL url = new URL(hostURL);
			connection = (HttpsURLConnection) url.openConnection();

			// Set up the connection properties
			connection.setRequestProperty("Connection", "close");
			// connection.setDoInput(true);
			connection.setDoOutput(true);
			connection.setUseCaches(false);
			connection.setConnectTimeout(30000);
			connection.setReadTimeout(30000);
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded; charset=UTF-8");
			connection.setRequestProperty("Content-Length",
					Integer.toString(requestParams.length()));

			connection.setSSLSocketFactory(this.factory);

			// Send the request
			OutputStream outputStream = connection.getOutputStream();
			outputStream.write(requestParams.getBytes("UTF-8"));
			outputStream.close();

			// Send post request
//			DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
//			wr.writeBytes(urlParameters);
//			wr.flush();
//			wr.close();

			int responseCode = connection.getResponseCode();
			logger.debug("Post parameters : " + requestParams);
			logger.debug("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(new InputStreamReader(
					connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			return response.toString();
		} catch (IOException ioe) {
			logger.debug("Got exception connection to civup: " + ioe.getMessage());
			throw ioe;
		} finally {
			// Always try to disconnect
			try {
				connection.disconnect();
			} catch (Throwable ex) {
				throw new IOException(
						"Unexpected error connection to Civilian Update TR Servlet");
			}
		}
	}

}
