package gov.nsa.deers;

import gov.nsa.utils.synchronization.SynchronizedBoolean;

import java.io.IOException;
import java.util.Collection;
import java.util.Properties;

import org.apache.log4j.Logger;


public class BatchUploader {
	private static final Logger logger = Logger.getLogger(BatchUploader.class
			.getName());

	private SynchronizedBoolean cancelled = new SynchronizedBoolean(false);

	public void cancel() {
		this.cancelled.setValue(true);
	}

//	public boolean upload(String keystorePath, String host, int port,
//			String passphrase, Collection<DEERSTransferRecord> transferRecords,
//			BatchUploaderObserver observer) throws IOException {
	public boolean upload(String keystorePath, String hostURL,
			String passphrase, Collection<DEERSTransferRecord> transferRecords,
			BatchUploaderObserver observer) throws IOException {
//		logger.info("uploading to " + host + ":" + port);
		logger.info("uploading to " + hostURL);

//		FormattedConnection c = new FormattedConnection(new Connection(
//				keystorePath, host, port, passphrase));
		
		FormattedConnection c = new FormattedConnection(new CivUptConnection(
				keystorePath, hostURL, passphrase));

		Properties properties = new Properties();
		properties.put("SCRTY_ID", "SMACHINE");
		properties.put("SITE_ID", "000062");
		properties.put("USER_ID", "0");

		String SCRTY_ID = properties.getProperty("SCRTY_ID");
		if (SCRTY_ID == null) {
			throw new RuntimeException("Missing property: SCRTY_ID");
		}
		if (properties.getProperty("SITE_ID") == null) {
			throw new RuntimeException("Missing property: SITE_ID");
		}
		int SITE_ID = Integer.parseInt(properties.getProperty("SITE_ID"));

		String USER_ID = properties.getProperty("USER_ID");
		if (USER_ID == null) {
			throw new RuntimeException("Missing property: USER_ID");
		}
		// int APP_ID = 259;
		// int APPL_VERS_NUM = 1;

		if (this.cancelled.getValue()) {
			return false;
		}
		logger.info("Using SCRTY_ID: " + SCRTY_ID);
		logger.info("Using SITE_ID: " + SITE_ID);
		logger.info("Using USER_ID: " + USER_ID);

		logger
				.info("Sending \"v\" request to get \"X\" response with run ID and submission ID to use for this batch");

		Header vRequest = new Header();

		java.util.Date now = new java.util.Date(System.currentTimeMillis());
		String SUBM_ID = "       0";
		String RUN_ID = "       0";
//		try {
//			vRequest.setHeaderFields(259, "v", 1, new Date(now), new Time(now),
//					"0", "00000", "00000000", "00000000", SCRTY_ID, SITE_ID,
//					USER_ID);
//
//			dumpToLog(vRequest);
//
//			XResponse xResponse = new XResponse();
//			c.sendReceive(vRequest, xResponse);
//
//			dumpToLog(xResponse);
//
//			if (!xResponse.getRawField("TXN_TYP_CD").equals("X")) {
//				throw new RuntimeException(
//						"Expected v transaction to result in TXN_TYP_CD=\"X\"");
//			}
//			SUBM_ID = FieldFormatter.formatZeroPaddedString(xResponse
//					.getColonTerminatedNumberField("X_SUBM_ID"), 8);
//			RUN_ID = FieldFormatter.formatZeroPaddedString(xResponse
//					.getColonTerminatedNumberField("X_RUN_ID"), 8);
//		} catch (FormatException e) {
//			throw new RuntimeException(e);
//		}

		logger.info("Using SUBM_ID: " + SUBM_ID);
		logger.info("Using RUN_ID: " + RUN_ID);

		for (DEERSTransferRecord rec : transferRecords) {
			if (cancelled.getValue()) {
				return false;
			}
			logger
					.debug("-----------------------------------------------------------------------------");

			Header ack = null;
			try {
				if (rec.getRawField("PNL_CAT_CD").trim().equals("E"))
					SCRTY_ID = "NGACNTR";
				else {
					SCRTY_ID = "SMACHINE";
				}

				now = new java.util.Date(System.currentTimeMillis());
				rec.setHeaderFields(259, "2", 1, new Date(now), new Time(now),
						"0", "00000", SUBM_ID, RUN_ID, SCRTY_ID, SITE_ID,
						USER_ID);

				dumpToLog(rec);

				ack = new Header();
				c.sendReceive(rec, ack);

				dumpToLog(ack);

				if ((!ack.getRawField("TXN_TYP_CD").equals("5"))
						|| (ack.getZeroPaddedNumField("TXN_RT_STAT_CD") != 0)
						|| (ack.getZeroPaddedNumField("TXN_RT_CD") != 0)) {
					if (observer != null) {
						observer.onNegativeAck(ack, rec);
					}
					logger.warn("Rejected: " + ack.getRawField("TXN_TYP_CD")
							+ ":" + ack.getZeroPaddedNumField("TXN_RT_STAT_CD")
							+ ":" + ack.getZeroPaddedNumField("TXN_RT_CD"));
				} else if (observer != null) {
					observer.onPositiveAck(ack, rec);
				}

			} catch (FormatException e) {
				observer.onFormatException(ack, rec, e);
			}
		}

		return true;
	}

	private static void dumpToLog(Record r) {
		try {
			StringBuffer b = new StringBuffer();
			b.append("\n");
			RecordDumper.dumpRecord(r, b);
			logger.debug(b);
		} catch (FormatException e) {
			logger.warn(e);
		}
	}
}