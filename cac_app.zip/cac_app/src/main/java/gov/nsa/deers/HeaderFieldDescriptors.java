package gov.nsa.deers;

public class HeaderFieldDescriptors {
	public static final String APP_ID = "APP_ID";
	public static final String TXN_TYP_CD = "TXN_TYP_CD";
	public static final String APPL_VERS_NUM = "APPL_VERS_NUM";
	public static final String TXN_ONL_DT = "TXN_ONL_DT";
	public static final String TXN_ONL_TM = "TXN_ONL_TM";
	public static final String TXN_RT_STAT_CD = "TXN_RT_STAT_CD";
	public static final String TXN_RT_CD = "TXN_RT_CD";
	public static final String SUBM_ID = "SUBM_ID";
	public static final String RUN_ID = "RUN_ID";
	public static final String SCRTY_ID = "SCRTY_ID";
	public static final String SITE_ID = "SITE_ID";
	public static final String USER_ID = "USER_ID";
	public static final FieldDescriptor[] headerFieldDescriptors = {
			new FieldDescriptor("Header", 1, 1, "Application Identifier", 4,
					"APP_ID", 4),
			new FieldDescriptor("Header", 2, 2, "Transaction Type Code", 1,
					"TXN_TYP_CD", 0),
			new FieldDescriptor("Header", 3, 3, "Application Version Number",
					2, "APPL_VERS_NUM", 0),
			new FieldDescriptor("Header", 4, 4,
					"Transaction On-line Date Format", 8, "TXN_ONL_DT", 2),
			new FieldDescriptor("Header", 5, 5,
					"Transaction On-line Time Format", 6, "TXN_ONL_TM", 3),
			new FieldDescriptor("Header", 6, 6,
					"Transaction Return Status Code", 1, "TXN_RT_STAT_CD", 0),
			new FieldDescriptor("Header", 7, 7, "Transaction Return Code", 5,
					"TXN_RT_CD", 0),
			new FieldDescriptor("Header", 8, 8, "Submission Identifier", 8,
					"SUBM_ID", 0),
			new FieldDescriptor("Header", 9, 9, "Run Identifier", 8, "RUN_ID",
					0),
			new FieldDescriptor("Header", 10, 10, "Security Identifier", 8,
					"SCRTY_ID", 1),
			new FieldDescriptor("Header", 11, 11, "Site Identifier", 6,
					"SITE_ID", 0),
			new FieldDescriptor("Header", 12, 12, "User Identifier", 8,
					"USER_ID", 0) };
}