package gov.nsa.deers;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

public class ReturnCodeMessages {
	// private static final String BUNDLE_NAME =
	// "com.quintron.deers.returnCodeMessages";
	private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle
			.getBundle("com.quintron.deers.returnCodeMessages");

	// private static String getString(String key)
	// {
	// try
	// {
	// return RESOURCE_BUNDLE.getString(key);
	// } catch (MissingResourceException e) {
	// }
	// return '!' + key + '!';
	// }

	public static String getReturnStatusCodeStr(String returnStatusCode) {
		return getStr("rsc." + returnStatusCode, null,
				'[' + returnStatusCode + ']');
	}

	public static String getReturnCodeStr(String returnStatusCode,
			String returnCode) {
		return getStr("rc." + returnStatusCode + "." + returnCode, "rc."
				+ returnStatusCode + "." + "OTHER", '[' + returnStatusCode
				+ '/' + returnCode + ']');
	}

	private static String getStr(String key0, String key1, String missingValue) {
		try {
			return RESOURCE_BUNDLE.getString(key0);
		} catch (MissingResourceException e0) {
			if (key1 == null)
				return missingValue;
			try {
				return RESOURCE_BUNDLE.getString(key1);
			} catch (MissingResourceException e1) {
			}
		}
		return missingValue;
	}
}