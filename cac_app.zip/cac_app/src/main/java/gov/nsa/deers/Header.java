package gov.nsa.deers;

public class Header extends Record {
	public static final RecordDescriptor recordDescriptor = new RecordDescriptor(
			HeaderFieldDescriptors.headerFieldDescriptors);

	protected Header(RecordDescriptor recordDescriptor) {
		super(recordDescriptor);
	}

	protected Header(RecordDescriptor recordDescriptor, String value)
			throws FormatException {
		super(recordDescriptor, value);
	}

	public Header() {
		super(recordDescriptor);
	}

	public Header(String value) throws FormatException {
		super(recordDescriptor, value);
	}

	public void setHeaderFields(int APP_ID, String TXN_TYP_CD,
			int APPL_VERS_NUM, Date TXN_ONL_DT, Time TXN_ONL_TM,
			String TXN_RT_STAT_CD, String TXN_RT_CD, String SUBM_ID,
			String RUN_ID, String SCRTY_ID, int SITE_ID, String USER_ID)
			throws FormatException {
		setZeroPaddedNumField("APP_ID", APP_ID);
		setRawField("TXN_TYP_CD", TXN_TYP_CD);
		setZeroPaddedNumField("APPL_VERS_NUM", APPL_VERS_NUM);
		setDateField("TXN_ONL_DT", TXN_ONL_DT);
		setTimeField("TXN_ONL_TM", TXN_ONL_TM);
		setRawField("TXN_RT_STAT_CD", TXN_RT_STAT_CD);
		setRawField("TXN_RT_CD", TXN_RT_CD);
		setRawField("SUBM_ID", SUBM_ID);
		setRawField("RUN_ID", RUN_ID);
		setTrailingSpacePaddedStringField("SCRTY_ID", SCRTY_ID);
		setZeroPaddedNumField("SITE_ID", SITE_ID);
		setTrailingSpacePaddedStringField("USER_ID", USER_ID);
	}
}