package gov.nsa.deers;

import java.util.Calendar;
import java.util.Date;

public class Time {
	private int hour;
	private int min;
	private int sec;

	public Time() {
	}

	public Time(Calendar calendar) {
		this(calendar.get(Calendar.HOUR), calendar.get(Calendar.MINUTE),
				calendar.get(Calendar.SECOND));
	}

	private static Calendar dateToCalendar(Date d) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(d);
		return calendar;
	}

	public Time(Date d) {
		this(dateToCalendar(d));
	}

	public Time(int hour, int min, int sec) {
		this.hour = hour;
		this.min = min;
		this.sec = sec;
	}

	public int getHour() {
		return this.hour;
	}

	public void setHour(int hour) {
		this.hour = hour;
	}

	public int getMin() {
		return this.min;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public int getSec() {
		return this.sec;
	}

	public void setSec(int sec) {
		this.sec = sec;
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (o.getClass() != getClass())
			return false;
		Time oCast = (Time) o;
		return (getHour() == oCast.getHour()) && (getMin() == oCast.getMin())
				&& (getSec() == oCast.getSec());
	}

	@Override
	public int hashCode() {
		return getHour() + getMin() + getSec();
	}

	private static String pad(int i) {
		return String.format("%02d", i);
	}

	@Override
	public String toString() {
		return "" + pad(getHour()) + ":" + pad(getMin()) + ":" + pad(getSec());
	}
}