package gov.nsa.deers;

import java.util.Calendar;

public class Date {
	private int year;
	private int month;
	private int day;

	public Date() {
	}

	public Date(Calendar calendar) {
		this(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + 1,
				calendar.get(Calendar.DATE));
	}

	private static Calendar dateToCalendar(java.util.Date d) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(d);
		return calendar;
	}

	public Date(java.util.Date d) {
		this(dateToCalendar(d));
	}

	public Date(int year, int month, int day) {
		this.year = year;
		this.month = month;
		this.day = day;
	}

	public int getDay() {
		return this.day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getMonth() {
		return this.month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return this.year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	@Override
	public boolean equals(Object o) {
		if (o == null)
			return false;
		if (o.getClass() != getClass())
			return false;
		Date oCast = (Date) o;
		return (getYear() == oCast.getYear())
				&& (getMonth() == oCast.getMonth())
				&& (getDay() == oCast.getDay());
	}

	@Override
	public int hashCode() {
		return getYear() + getMonth() + getDay();
	}

	@Override
	public String toString() {
		return "" + getYear() + "-" + getMonth() + "-" + getDay();
	}
}