package gov.nsa.deers;

import org.apache.log4j.Logger;

public class LoggingBatchUploaderObserver implements BatchUploaderObserver {
	static Logger logger = Logger.getLogger(Connection.class.getName());

	@Override
	public void onFormatException(Header ack, DEERSTransferRecord rec,
			FormatException e) {
		logger.warn(rec);
		logger.warn(ack);
		logger.warn(e);
	}

	@Override
	public void onNegativeAck(Header ack, DEERSTransferRecord rec) {
		logger.warn(rec);
		logger.warn(ack);
	}

	@Override
	public void onPositiveAck(Header ack, DEERSTransferRecord rec) {
		logger.info(rec);
		logger.info(ack);
	}
}