package gov.nsa.deers;

public class XResponse extends Header {
	public static final String X1 = "X1";
	public static final String X_SUBM_ID = "X_SUBM_ID";
	public static final String X3 = "X3";
	public static final String X_RUN_ID = "X_RUN_ID";
	public static final RecordDescriptor recordDescriptor = new RecordDescriptor(
			HeaderFieldDescriptors.headerFieldDescriptors,
			new FieldDescriptor[] {
					new FieldDescriptor("X", 13, -1, "X1", 6, "X1", 4),
					new FieldDescriptor("X", 14, -1, "X Submission ID", 9,
							"X_SUBM_ID", 5),
					new FieldDescriptor("X", 15, -1, "X3", 6, "X3", 4),
					new FieldDescriptor("X", 16, -1, "X Run ID", 9, "X_RUN_ID",
							5) });

	public XResponse() {
		super(recordDescriptor);
	}

	public XResponse(String value) throws FormatException {
		super(recordDescriptor, value);
	}
}

/*
 * Location: C:\Documents and
 * Settings\mdsholu\Desktop\deers.gui-20081001-1457\deers.gui\ Qualified Name:
 * com.quintron.deers.XResponse JD-Core Version: 0.6.2
 */