package gov.nsa.deers;

public interface BatchUploaderObserver {
	void onPositiveAck(Header paramHeader,
			DEERSTransferRecord paramDEERSTransferRecord);

	void onNegativeAck(Header paramHeader,
			DEERSTransferRecord paramDEERSTransferRecord);

	void onFormatException(Header paramHeader,
			DEERSTransferRecord paramDEERSTransferRecord,
			FormatException paramFormatException);
}