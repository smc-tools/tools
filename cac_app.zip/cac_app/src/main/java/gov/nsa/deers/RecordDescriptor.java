package gov.nsa.deers;

import java.util.HashMap;
import java.util.Map;

public class RecordDescriptor {
	private FieldDescriptor[] fieldDescriptors;
	private Map<String, FieldDescriptor> indexByColumnName = new HashMap<String, FieldDescriptor>();

	public RecordDescriptor(FieldDescriptor[] fieldDescriptors) {
		this.fieldDescriptors = fieldDescriptors;
		buildIndex();
	}

	public RecordDescriptor(FieldDescriptor[] fieldDescriptors1,
			FieldDescriptor[] fieldDescriptors2) {
		this.fieldDescriptors = new FieldDescriptor[fieldDescriptors1.length
				+ fieldDescriptors2.length];
		System.arraycopy(fieldDescriptors1, 0, this.fieldDescriptors, 0,
				fieldDescriptors1.length);
		System.arraycopy(fieldDescriptors2, 0, this.fieldDescriptors,
				fieldDescriptors1.length, fieldDescriptors2.length);

		buildIndex();
	}

	// private void verifyAscending()
	// {
	// for (int i = 0; i < this.fieldDescriptors.length; i++)
	// {
	// FieldDescriptor fd = this.fieldDescriptors[i];
	// if (fd.getGlobalNumber() != i + 1)
	// throw new RuntimeException("Global number does not match for column " +
	// fd.getColumnName());
	// }
	// }

	public int getNumFields() {
		return this.fieldDescriptors.length;
	}

	public String[] getColumnNames() {
		int numFields = this.fieldDescriptors.length;
		String[] result = new String[numFields];
		for (int i = 0; i < numFields; i++) {
			result[i] = this.fieldDescriptors[i].getColumnName();
		}
		return result;
	}

	public FieldDescriptor[] getFieldDescriptors() {
		return this.fieldDescriptors;
	}

	public int getOffset(String columnName) {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return getOffset(fd);
	}

	public int getLength(String columnName) {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return fd.getLength();
	}

	public boolean isVariableLength(String columnName) {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return fd.isVariableLength();
	}

	public int getType(String columnName) {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return fd.getType();
	}

	public int getOffset(FieldDescriptor fd) {
		int offset = 0;
		for (FieldDescriptor descriptor : fieldDescriptors) {
			if (descriptor == fd) {
				return offset;
			}
			offset += descriptor.getLength();
		}
		throw new IllegalArgumentException("Unknown column");
	}

	public int getTotalLength(char[] data) throws FormatException {
		int length = 0;
		for (FieldDescriptor fd : fieldDescriptors) {
			length += fd.getVariableLength(data, length);
		}
		return length;
	}

	public int getOffset(FieldDescriptor fd, char[] data)
			throws FormatException {
		int offset = 0;
		for (FieldDescriptor descriptor : fieldDescriptors) {
			if (descriptor == fd)
				return offset;
			offset += descriptor.getVariableLength(data, offset);
		}
		throw new IllegalArgumentException("Unknown column");
	}

	public int getOffset(String columnName, char[] data) throws FormatException {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return getOffset(fd, data);
	}

	public int getVariableLength(String columnName, char[] data, int dataOffset)
			throws FormatException {
		FieldDescriptor fd = getFieldDescriptorByColumnName(columnName);
		if (fd == null)
			throw new IllegalArgumentException("Unknown column: " + columnName);
		return fd.getVariableLength(data, dataOffset);
	}

	public int getTotalLength() {
		int length = 0;
		for (FieldDescriptor descriptor : fieldDescriptors) {
			length += descriptor.getLength();
		}
		return length;
	}

	private FieldDescriptor getFieldDescriptorByColumnName(String columnName) {
		return this.indexByColumnName.get(columnName);
	}

	private void buildIndex() {
		this.indexByColumnName.clear();
		for (FieldDescriptor fd : fieldDescriptors) {
			if (getFieldDescriptorByColumnName(fd.getColumnName()) != null)
				throw new RuntimeException("Duplicate column name: "
						+ fd.getColumnName());
			this.indexByColumnName.put(fd.getColumnName(), fd);
		}
	}
}