package gov.nsa.deers;

public class FieldDescriptor {
	private String section;
	private int globalNumber;
	private int localNumber;
	private String attributeDescription;
	private int length;
	private String columnName;
	private int type;
	public static final int RAW_STRING = 0;
	public static final int TRAILING_SPACE_PADDED_STRING = 1;
	public static final int DATE = 2;
	public static final int TIME = 3;
	public static final int ZERO_PADDED_NUM = 4;
	public static final int COLON_TERMINATED_NUM = 5;

	public static String typeToString(int type) {
		switch (type) {
		case 0:
			return "Raw string";
		case 1:
			return "Trailing-space-padded string";
		case 2:
			return "Date";
		case 3:
			return "Time";
		case 4:
			return "0-padded number";
		case 5:
			return "Colon-terminated number";
		}
		throw new IllegalArgumentException("Unknown type: " + type);
	}

	public FieldDescriptor(String section, int globalNumber, int localNumber,
			String attributeDescription, int length, String columnName, int type) {
		this.section = section;
		this.globalNumber = globalNumber;
		this.localNumber = localNumber;
		this.attributeDescription = attributeDescription;
		this.length = length;
		this.columnName = columnName;
		this.type = type;
	}

	public String getAttributeDescription() {
		return this.attributeDescription;
	}

	public void setAttributeDescription(String attributeDescription) {
		this.attributeDescription = attributeDescription;
	}

	public String getColumnName() {
		return this.columnName;
	}

	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}

	public int getGlobalNumber() {
		return this.globalNumber;
	}

	public void setGlobalNumber(int globalNumber) {
		this.globalNumber = globalNumber;
	}

	public int getLength() {
		return this.length;
	}

	public boolean isVariableLength() {
		return this.type == 5;
	}

	public int getVariableLength(char[] data, int dataOffset)
			throws FormatException {
		if (!isVariableLength())
			return this.length;
		if (this.type != 5) {
			throw new RuntimeException(
					"Expected type to be COLON_TERMINATED_NUM");
		}
		for (int i = 0; i < this.length; i++) {
			if (i >= data.length)
				throw new FormatException("Expected :");
			if (data[(dataOffset + i)] == ':')
				return i + 1;
		}
		throw new FormatException("Expected :");
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getLocalNumber() {
		return this.localNumber;
	}

	public void setLocalNumber(int localNumber) {
		this.localNumber = localNumber;
	}

	public String getSection() {
		return this.section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public int getType() {
		return this.type;
	}

	public void setType(int type) {
		this.type = type;
	}
}