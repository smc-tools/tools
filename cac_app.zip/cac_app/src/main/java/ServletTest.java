import gov.nsa.deers.FormatException;
import gov.nsa.deers.Header;
import gov.nsa.deers.Record;
import gov.nsa.deers.RecordDumper;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class ServletTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HttpURLConnection connection = null;
		try {
			// HTTPS
			//URL url = new URL("https://localhost:15212/civupt/TRServlet");
			
			//HTTP
			//URL url = new URL("http://localhost:15211/civupt/TRServlet");
			
			URL url = new URL("http://wt1.int.dmdc.osd.mil/civupt/TRServlet");
			
			connection = (HttpURLConnection) url.openConnection();
			String contentType = "application/x-www-form-urlencoded; charset=UTF-8";
			connection.setRequestProperty("Content-Type", contentType);
			String urlParameters = "msg="
					+ "025920120050922124220000000       0       0MACHINE 0001030       558722487SKrull                     Halbarad                                    19681010  USC20050101        U        WDD00G20050304  999AA20050101        ";

			// Send post request
			connection.setDoOutput(true);
			DataOutputStream wr = new DataOutputStream(
					connection.getOutputStream());
			wr.writeBytes(urlParameters);
			wr.flush();
			wr.close();

			int responseCode = connection.getResponseCode();
			System.out.println("\nSending 'POST' request to URL : " + url);
			System.out.println("Post parameters : " + urlParameters);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(new InputStreamReader(
					connection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			// print result
			System.out.println("Response: [" + response.toString() + "]");
			Header ack = new Header();
			ack.setFrom(response.toString());
			dumpToLog(ack);

		} catch (IOException io) {
			io.printStackTrace();
			System.out.println(io.getMessage());

		} catch (FormatException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		} finally {
			// Always try to disconnect
			try {
				connection.disconnect();
			} catch (Throwable ex) {
				ex.printStackTrace();
				System.out.println("Could not disconnect HttpURLConnection.");
			}
		}
	}

	private static void dumpToLog(Record r) {
		try {
			StringBuffer b = new StringBuffer();
			b.append("\n");
			RecordDumper.dumpRecord(r, b);
			System.out.println("Response record: " + b);
		} catch (FormatException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
}
