import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class SSLclient {
	public static void main(String[] args) throws Exception {
		String host = null;
		int port = -1;
		int iLength = 0;
		char[] chReturn = new char[14];
		String sOutput = "";
		int iSize = 0;
		StringBuffer sbOutTRSize = new StringBuffer("000000");
		String sTR = "025920120021217002020000000                "
				+ "TJTTXXX 40010017803   "
				+ "610616100SSMITH                     "
				+ "JOHN                JAMES               III "
				+ "19701010MNUSE2000010120020101S200201012121812003030412345AA20010101NASABASE";
		String sPreamble = "DSC1,  $MACHINE CERT    ";

		for (int i = 0; i < args.length; i++) {
			System.out.println(args[i]);
		}
		if (args.length < 2) {
			System.out
					.println("USAGE: java SSLSocketClientWithClientAuth host port");

			System.exit(-1);
		}
		try {
			host = args[0];
			port = Integer.parseInt(args[1]);
		} catch (IllegalArgumentException e) {
			System.out
					.println("USAGE: java SSLSocketClientWithClientAuth host port requestedfilepath");

			System.exit(-1);
		}

		try {
			SSLSocketFactory factory = null;
			try {
				char[] passphrase = "rapids".toCharArray();

				SSLContext ctx = SSLContext.getInstance("TLS");
				KeyManagerFactory kmf = KeyManagerFactory
						.getInstance("SunX509");
				KeyStore ks = KeyStore.getInstance("JKS");

				InputStream is = ClassLoader.getSystemClassLoader()
						.getResourceAsStream("victor.jks");

				ks.load(is, passphrase);

				kmf.init(ks, passphrase);
				ctx.init(kmf.getKeyManagers(), null, null);

				factory = ctx.getSocketFactory();
			} catch (Exception e) {
				throw new IOException(e.getMessage());
			}

			SSLSocket socket = (SSLSocket) factory.createSocket(host, port);

			socket.setKeepAlive(true);

			socket.startHandshake();

			BufferedReader br = new BufferedReader(new InputStreamReader(socket
					.getInputStream()));
			PrintWriter pw = new PrintWriter(socket.getOutputStream());

			System.out.println("Sending: " + sPreamble);
			pw.print(sPreamble);
			pw.flush();

			iLength = br.read(chReturn, 0, 14);
			sOutput = String.valueOf(chReturn);
			System.out.println("Length: " + iLength + " sOutput Returned: "
					+ sOutput);
			if (sOutput.equals("READY UNIKIX01")) {
				sbOutTRSize.replace(sbOutTRSize.length()
						- ("" + sTR.length()).length(), sbOutTRSize.length(),
						"" + sTR.length());
				System.out.println("Sending: " + sbOutTRSize.toString());
				pw.print(sbOutTRSize.toString());
				pw.flush();

				System.out.println("Sending: " + sTR);
				pw.print(sTR);
				pw.flush();

				chReturn = new char[6];
				iLength = br.read(chReturn, 0, 6);
				sOutput = String.valueOf(chReturn);
				System.out.println("Length: " + iLength + " sOutput Returned: "
						+ sOutput);
				iSize = Integer.parseInt(sOutput);

				chReturn = new char[iSize];
				iLength = br.read(chReturn, 0, iSize);
				sOutput = String.valueOf(chReturn);
				System.out.println("Length: " + iLength + " sOutput Returned: "
						+ sOutput);
			}

			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}