package gov.nsa.deers.test;

import gov.nsa.deers.Connection;

public class ConnectionTest {
	public static void main(String[] args) throws Exception {
		String sTR = "025920120021217002020000000                TJTTXXX 40010017803   610616100SSMITH                     JOHN                JAMES               III 19701010MNUSE2000010120020101S200201012121812003030412345AA20010101NASABASE";
		Connection c = new Connection("victor.jks", "214.3.119.51", 443,
				"rapids");

		String sResult = c.sendReceive(sTR);

		System.out.println(sResult);
	}
}