package gov.nsa.deers.test;

import gov.nsa.deers.DEERSTransferRecord;
import gov.nsa.deers.FormatException;
import gov.nsa.deers.Header;
import gov.nsa.deers.RecordDumper;

import org.junit.Test;


public class FormatTest {

	@Test
	public void testFormat() throws FormatException {
		String str = "025920120021217002020000000                TJTTXXX 40010017803   610616100SSMITH                     JOHN                JAMES               III 19701010MNUSE2000010120020101S200201012121812003030412345AA20010101NASABASE";
		DEERSTransferRecord rec = new DEERSTransferRecord(str);
		RecordDumper.dumpRecord(rec, System.out);

		System.out.println("\n-----------------\n");

		Header ack = new Header(
				"0259E01200407090505073000530000000000000000TJTTXXX 40010000017803");
		RecordDumper.dumpRecord(ack, System.out);
	}
}