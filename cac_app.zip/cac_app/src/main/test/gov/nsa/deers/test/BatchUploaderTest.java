package gov.nsa.deers.test;

import gov.nsa.deers.BatchUploader;
import gov.nsa.deers.DEERSTransferRecord;
import gov.nsa.deers.LoggingBatchUploaderObserver;

import java.util.ArrayList;
import java.util.Collection;


public class BatchUploaderTest {
	public static void main(String[] args) throws Exception {
		Collection<DEERSTransferRecord> records = new ArrayList<DEERSTransferRecord>();

		for (int i = 0; i < 3; i++) {
			String sTR = "025920120021217002020000000                "
					+ "TJTTXXX 4001001821    610616100SSMITH                     JOHN                JAMES               III "
					+ "19701010MNUSC2000010120020101U00000000WAF2S12003030412345AA20010101NASABASE";
			DEERSTransferRecord rec = new DEERSTransferRecord(sTR);
			records.add(rec);
		}

		new BatchUploader().upload("victor.jks", "http://localhost:15211/civupt/TRServlet", "rapids",
				records, new LoggingBatchUploaderObserver());
	}
}