package gov.nsa.deers.test;

import gov.nsa.deers.Connection;
import gov.nsa.deers.DEERSTransferRecord;
import gov.nsa.deers.FormattedConnection;
import gov.nsa.deers.Header;
import gov.nsa.deers.RecordDumper;

public class FormattedConnectionTest {
	public static void main(String[] args) throws Exception {
		FormattedConnection c = new FormattedConnection(new Connection(
				"victor.jks", "http://localhost:15211/civupt/TRServlet", "rapids"));

		String sTR = "025920120021217002020000000                "
				+ "TJTTXXX 4001001821    610616100SSMITH                     JOHN                JAMES               III "
				+ "19701010MNUSC2000010120020101U00000000WAF2S12003030412345AA20010101NASABASE";

		// Header v = new
		// Header("0259v0120030729093711000000  SMACHINE 0000620 ");
		DEERSTransferRecord rec = new DEERSTransferRecord(sTR);

		RecordDumper.dumpRecord(rec, System.out);

		Header ack = new Header();
		c.sendReceive(rec, ack);
		System.out.println(ack.toString());

		RecordDumper.dumpRecord(ack, System.out);
	}
}