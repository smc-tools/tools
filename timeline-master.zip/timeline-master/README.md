# Timeline
Clustering in timeline modified from visjs http://visjs.org/ 

