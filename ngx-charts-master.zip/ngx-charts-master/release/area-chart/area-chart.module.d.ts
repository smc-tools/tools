export declare class AreaChartModule {
}
