export declare let colorSets: {
    name: string;
    selectable: boolean;
    group: string;
    domain: string[];
}[];
