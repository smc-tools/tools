export declare function sortLinear(data: any, property: any, direction?: string): any;
export declare function sortByDomain(data: any, property: any, direction: string, domain: any): any;
export declare function sortByTime(data: any, property: any, direction?: string): any;
