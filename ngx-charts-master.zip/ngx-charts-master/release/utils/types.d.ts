export declare function isDate(value: any): boolean;
export declare function isNumber(value: any): boolean;
