export declare class PieChartModule {
}
