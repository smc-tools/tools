export declare function tickFormat(fieldType: any, groupByType: any): (label: string) => string;
