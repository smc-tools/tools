export * from './tooltip.module';
export * from './tooltip.service';
export * from './tooltip.component';
export * from './tooltip.directive';
export * from './style.type';
export * from './alignment.type';
export * from './show.type';
//# sourceMappingURL=index.js.map