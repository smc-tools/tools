export declare enum AlignmentTypes {
    left,
    center,
    right
}
