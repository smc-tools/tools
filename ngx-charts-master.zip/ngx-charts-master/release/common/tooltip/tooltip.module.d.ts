export declare class TooltipModule {
}
