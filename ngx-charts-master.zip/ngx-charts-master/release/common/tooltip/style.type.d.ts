export declare enum StyleTypes {
    popover,
    tooltip
}
