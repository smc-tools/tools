export declare enum ShowTypes {
    all,
    focus,
    mouseover
}
