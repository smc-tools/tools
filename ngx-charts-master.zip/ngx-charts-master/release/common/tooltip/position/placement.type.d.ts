export declare enum PlacementTypes {
    top,
    bottom,
    left,
    right
}
