export declare function gridSize(dims: any, len: any, minWidth: any): any[];
export declare function gridLayout(dims: any, data: any, minWidth: any, designatedTotal: any): any[];
