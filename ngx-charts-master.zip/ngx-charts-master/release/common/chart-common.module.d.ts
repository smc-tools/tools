export declare class ChartCommonModule {
}
