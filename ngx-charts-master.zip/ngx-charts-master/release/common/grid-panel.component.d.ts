export declare class GridPanelComponent {
    path: any;
    width: any;
    height: any;
    x: any;
    y: any;
}
