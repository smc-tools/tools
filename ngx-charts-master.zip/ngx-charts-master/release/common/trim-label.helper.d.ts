export declare function trimLabel(s: any, max?: number): string;
