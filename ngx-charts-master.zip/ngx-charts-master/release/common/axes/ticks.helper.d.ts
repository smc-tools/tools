export declare function reduceTicks(ticks: any, maxTicks: any): any;
