export declare class AxesModule {
}
