export * from './axes.module';
export * from './axis-label.component';
export * from './x-axis.component';
export * from './x-axis-ticks.component';
export * from './y-axis.component';
export * from './y-axis-ticks.component';
export * from './ticks.helper';
//# sourceMappingURL=index.js.map