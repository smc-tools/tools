export * from './chart.component';
//# sourceMappingURL=index.js.map