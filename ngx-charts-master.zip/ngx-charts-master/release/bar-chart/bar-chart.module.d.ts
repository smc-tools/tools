export declare class BarChartModule {
}
