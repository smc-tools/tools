export declare class LineChartModule {
}
