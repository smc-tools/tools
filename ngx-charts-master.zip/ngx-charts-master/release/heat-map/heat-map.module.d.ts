export declare class HeatMapModule {
}
