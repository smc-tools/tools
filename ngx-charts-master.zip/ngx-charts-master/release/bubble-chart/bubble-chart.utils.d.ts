export declare function getDomain(values: any, scaleType: any, autoScale: any, minVal?: any, maxVal?: any): number[];
export declare function getScale(domain: any, range: number[], scaleType: any, roundDomains: any): any;
