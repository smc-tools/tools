export declare class BubbleChartModule {
}
