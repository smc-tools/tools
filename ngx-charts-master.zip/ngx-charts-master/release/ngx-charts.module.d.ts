import './polyfills';
export declare class NgxChartsModule {
}
