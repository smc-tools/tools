export declare const MouseEvent: MouseEvent & (new (typeArg: string, eventInitDict?: MouseEventInit) => MouseEvent);
