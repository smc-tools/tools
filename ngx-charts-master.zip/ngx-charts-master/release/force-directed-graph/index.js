export * from './force-directed-graph.module';
export * from './force-directed-graph.component';
//# sourceMappingURL=index.js.map