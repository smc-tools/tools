export declare class ForceDirectedGraphModule {
}
