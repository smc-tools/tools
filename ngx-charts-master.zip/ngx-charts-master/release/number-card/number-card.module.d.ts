export declare class NumberCardModule {
}
