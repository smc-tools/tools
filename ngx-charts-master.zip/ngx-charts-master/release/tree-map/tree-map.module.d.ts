export declare class TreeMapModule {
}
