export declare function ngxChartsPolyfills(): void;
