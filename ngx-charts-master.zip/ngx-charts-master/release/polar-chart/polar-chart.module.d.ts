export declare class PolarChartModule {
}
