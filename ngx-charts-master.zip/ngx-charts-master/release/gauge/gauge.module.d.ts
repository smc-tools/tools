export declare class GaugeModule {
}
