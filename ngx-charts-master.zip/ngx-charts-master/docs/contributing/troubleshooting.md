# Troubleshooting

## Browser Support

ngx-charts is built on top of Angular2+, as such we only support the browsers it supports. [Check here](https://angular.io/docs/ts/latest/guide/browser-support.html) for the official supported browsers by Angular.

