# Building

This project uses [npm tasks](https://www.keithcirkel.co.uk/how-to-use-npm-as-a-build-tool/) for builds.

* `npm start`: Starts the demo chart builder page
* `npm run build`: Compiles the code
* `npm run test`: Runs Tests
* `npm run package`: Compiles and bundles the package
* `npm run release`: Compiles the demo chart builder page

