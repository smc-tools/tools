'use strict';
module.exports = require('@swimlane/prettier-config-swimlane');
