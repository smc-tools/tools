Sources:

* ng-jsf-...json files are new examples created for angular2-json-schema-form

* json-schema-draft...json files are JSON Meta-Schemas,
  [available here](http://json-schema.org/specification-links.html)

* asf-...json files are Angular Schema Form (AngularJS) compatibility examples,
  [available here](http://schemaform.io/examples/bootstrap-example.html)

* jsf-...json files are JSONForm (jQuery) compatibility examples,
  [available here](http://ulion.github.io/jsonform/playground/)

* rjsf-...json files are React JSON Schema Form compatibility examples,
  [available here](https://mozilla-services.github.io/react-jsonschema-form/)
